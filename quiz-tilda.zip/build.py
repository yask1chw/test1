from pathlib import Path
import base64, re

ROOT = Path(__file__).resolve().parent
def read(name): return (ROOT / name).read_text()
def data(path, mime): return 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode()

fonts = ''
font_dir = ROOT / 'fonts'
for weight in [400, 600]:
    for script, charset in [('cyrillic', 'U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116'), ('latin', 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD')]:
        path = font_dir / f'manrope-{script}-{weight}-normal.woff2'
        fonts += "@font-face{font-family:'AQ Manrope';font-style:normal;font-weight:" + str(weight) + ";font-display:swap;src:url('" + data(path, 'font/woff2') + "') format('woff2');unicode-range:" + charset + ';}\n'
css = fonts + read('quiz.css')
markup = read('quiz-markup.html')
for path in (ROOT / 'images').glob('*.webp'):
    markup = markup.replace('images/' + path.name, data(path, 'image/webp'))
def script(text): return '<script>\n' + re.sub(r'</script', r'<\\/script', text, flags=re.I) + '\n</script>\n'

common = '<style>\n' + css + '\n</style>\n' + markup + '\n'
code = script(read('quiz-config.js')) + script(read('tilda-form-bridge.js')) + script(read('quiz.js'))
(ROOT / 'quiz-tilda.js').write_text(read('quiz-config.js') + '\n' + read('tilda-form-bridge.js') + '\n' + read('quiz.js'))
(ROOT / 'tilda-block.html').write_text('<!-- Paste into ONE T123 block. Set formBlock below to your native Tilda form record. -->\n' + common + code)
demo = '<div class="aq-demo-notice" style="padding:12px 20px;background:#eee5d9;color:#39352f;font:14px Arial">Демонстрация квиза. Реальные заявки не отправляются. Для сайта используйте tilda-block.html.</div>'
demo_code = '''window.AVDEEvaQuizConfig.formBlock='#rec123456789';
document.querySelector('#rec123456789 form').addEventListener('submit',function(e){
  e.preventDefault();
  window.lastDemoPayload=Array.from(new FormData(this).entries());
  this.dispatchEvent(new Event('tildaform:aftersuccess'));
});'''
page = '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Квиз проектирования дома — демонстрация</title><meta name="robots" content="noindex,nofollow"><style>body{margin:0;background:#fbf8f4}</style></head><body>' + demo + read('preview-native-form.html') + common + script(read('quiz-config.js')) + script(demo_code) + script(read('tilda-form-bridge.js')) + script(read('quiz.js')) + '</body></html>'
(ROOT / 'quiz-preview.html').write_text(page)
print('Built self-contained T123 block:', (ROOT / 'tilda-block.html').stat().st_size, 'bytes')
print('Built self-contained browser preview:', (ROOT / 'quiz-preview.html').stat().st_size, 'bytes')
