(function () {
  'use strict';
  function init() {
    const root = document.getElementById('avdeeva-quiz');
    if (!root || root.dataset.quizInitialized) return;
    root.dataset.quizInitialized = 'true';
    const config = window.AVDEEvaQuizConfig || {};
    const steps = Array.from(root.querySelectorAll('[data-step]'));
    const layout = root.querySelector('[data-quiz-layout]');
    const contact = root.querySelector('[data-contact]');
    const thanks = root.querySelector('[data-thanks]');
    const error = root.querySelector('[data-question-error]');
    const back = root.querySelector('.aq-back');
    const next = root.querySelector('.aq-next');
    let current = 0;
    let bridge = null;
    let completed = false;

    function answers() {
      return steps.map(step => ({
        question: step.querySelector('h2').textContent,
        value: step.querySelector('input:checked')?.value || ''
      }));
    }
    function focusTitle(title) {
      title.focus({ preventScroll: true });
      if (root.getBoundingClientRect().top < -80) root.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    function showStep(index, focus) {
      current = index;
      steps.forEach((step, i) => { step.hidden = i !== index; });
      layout.hidden = false;
      root.querySelector('.aq-heading').hidden = false;
      contact.hidden = true;
      thanks.hidden = true;
      back.disabled = index === 0;
      error.hidden = true;
      const progress = [0, 33, 67][index];
      root.querySelector('[data-progress-label]').textContent = progress + '%';
      root.querySelector('[data-progress-fill]').style.width = progress + '%';
      root.querySelector('.aq-navigation [role="progressbar"]').setAttribute('aria-valuenow', String(progress));
      root.querySelector('[data-next-label]').textContent = index === 2 ? 'Последний шаг' : 'Далее';
      if (focus) focusTitle(steps[index].querySelector('h2'));
    }
    function success() {
      if (completed || answers().some(answer => !answer.value)) return;
      completed = true;
      contact.hidden = true;
      layout.hidden = true;
      root.querySelector('.aq-heading').hidden = true;
      thanks.hidden = false;
      focusTitle(root.querySelector('#aq-thanks-title'));
    }
    function connectForm() {
      try {
        bridge = new window.TildaQuizFormBridge(config);
        bridge.mountContactForm(root.querySelector('[data-native-form-slot]'), success);
        root.querySelector('.aq-form-unavailable').hidden = true;
      } catch (err) {
        bridge = null;
        root.querySelector('.aq-form-unavailable').hidden = false;
        console.warn('Quiz: set formBlock to the ID of your native Tilda form.', err);
      }
    }
    function advance() {
      const selected = steps[current].querySelector('input:checked');
      if (!selected) {
        error.hidden = false;
        steps[current].querySelector('input').focus();
        return;
      }
      if (current < 2) return showStep(current + 1, true);
      if (!bridge) connectForm();
      if (bridge) bridge.setAnswers(answers());
      layout.hidden = true;
      root.querySelector('.aq-heading').hidden = true;
      contact.hidden = false;
      error.hidden = true;
      focusTitle(root.querySelector('#aq-contact-title'));
      window.dispatchEvent(new Event('resize'));
    }
    next.addEventListener('click', advance);
    back.addEventListener('click', () => { if (current > 0) showStep(current - 1, true); });
    root.querySelector('.aq-edit').addEventListener('click', () => { if (!completed) showStep(2, true); });
    root.addEventListener('change', event => {
      if (!event.target.matches('.aq-step input[type="radio"]')) return;
      error.hidden = true;
      if (bridge) bridge.setAnswers(answers());
    });
    root.addEventListener('keydown', event => {
      if (event.key !== 'Enter' || event.isComposing || layout.hidden) return;
      // Native buttons retain their normal keyboard activation; no double advance.
      if (event.target.closest('button, a, textarea, select')) return;
      event.preventDefault();
      advance();
    });
    if (config.advisorPhoto) {
      const photo = document.createElement('img');
      photo.src = config.advisorPhoto;
      photo.alt = '';
      photo.width = 44;
      photo.height = 44;
      root.querySelector('.aq-avatar').replaceChildren(photo);
    }
    showStep(0, false);
    connectForm();
  }
  // Let the page's native form initializers run before moving the complete record.
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(init, 0), { once: true });
  else setTimeout(init, 0);
})();
