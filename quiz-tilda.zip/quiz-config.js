window.AVDEEvaQuizConfig = {
  // Change this to the ID of your native Tilda contact-form block before publishing.
  formBlock: '#rec000000000',
  quizName: 'Проектирование дома — Avdeeva Architects',
  fieldName: 'QuizAnswers',
  advisorPhoto: ''
};
