/* Connect a custom quiz to an existing native Tilda form. No third-party lead endpoint. */
(function (global) {
  'use strict';
  class TildaQuizFormBridge {
    constructor(options) {
      if (!options || !/^#rec\d+$/.test(options.formBlock || '')) {
        throw new Error('Укажите ID блока штатной формы Тильды: например, #rec123456789.');
      }
      this.selector = options.formBlock;
      this.fieldName = options.fieldName || 'QuizAnswers';
      this.quizName = options.quizName || 'Квиз';
      this.answers = [];
      this.form = null;
      this.successListeners = [];
      this.mountPoint = null;
      this.handleSubmit = () => this.writeFields();
    }

    setAnswers(answers) {
      if (!Array.isArray(answers)) throw new TypeError('Expected a list of quiz answers.');
      // Replace the whole current path: answers from abandoned branches are not retained.
      this.answers = answers.map(function (answer) {
        if (!answer || typeof answer.question !== 'string') throw new TypeError('Missing question text.');
        const values = Array.isArray(answer.value) ? answer.value : [answer.value];
        return { question: answer.question, values: values.filter(v => v !== null && v !== undefined).map(String) };
      });
      if (this.form) this.writeFields();
    }

    resolveForm() {
      const block = document.querySelector(this.selector);
      if (!block) throw new Error('Блок формы не найден: ' + this.selector);
      const forms = block.querySelectorAll('form[data-formactiontype="2"]');
      if (forms.length !== 1) throw new Error('В выбранном блоке должна быть одна штатная форма Тильды.');
      return { block: block, form: forms[0] };
    }

    attach() {
      const target = this.resolveForm();
      if (this.form === target.form) return target;
      this.destroy();
      this.form = target.form;
      this.writeFields();
      this.form.addEventListener('submit', this.handleSubmit, true);
      return target;
    }

    setHidden(name, value) {
      const fields = Array.from(this.form.elements).filter(input => input.name === name);
      if (fields.some(input => input.getAttribute('data-quiz-bridge') !== this.selector)) {
        throw new Error('Имя поля уже занято в форме: ' + name);
      }
      let input = fields[0];
      if (!input) {
        input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.className = 't-input';
        input.setAttribute('data-quiz-bridge', this.selector);
        this.form.appendChild(input);
      }
      input.value = value;
    }

    writeFields() {
      this.setHidden(this.fieldName, this.answers.map(function (answer, index) {
        return (index + 1) + '. ' + answer.question + '\n' + answer.values.join('; ');
      }).join('\n\n'));
      this.setHidden(this.fieldName + 'Source', this.quizName);
    }

    showContactForm() {
      const target = this.attach();
      // The native form keeps its own receivers, contact inputs, validation and PD consent.
      target.block.hidden = false;
      target.block.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return target.form;
    }

    mountContactForm(slot, onSuccess) {
      const target = this.attach();
      if (!slot || !(slot instanceof Element)) throw new Error('Contact form slot not found.');
      if (!this.mountPoint) {
        this.mountPoint = document.createComment('Native Tilda form original position');
        target.block.parentNode.insertBefore(this.mountPoint, target.block);
      }
      // Move the entire native record, preserving #rec, form, bound handlers and validation.
      target.block.classList.add('aq-native-form');
      slot.appendChild(target.block);
      const success = () => { if (typeof onSuccess === 'function') onSuccess(); };
      target.form.addEventListener('tildaform:aftersuccess', success);
      this.successListeners.push(() => target.form.removeEventListener('tildaform:aftersuccess', success));
      if (global.jQuery) {
        global.jQuery(target.form).on('tildaform:aftersuccess', success);
        this.successListeners.push(() => global.jQuery(target.form).off('tildaform:aftersuccess', success));
      }
      this.setHidden(this.fieldName + 'ContactChannel', 'WhatsApp');
      return target.form;
    }

    destroy() {
      if (!this.form) return;
      this.successListeners.forEach(remove => remove());
      this.successListeners = [];
      this.form.removeEventListener('submit', this.handleSubmit, true);
      const block = this.form.closest(this.selector);
      if (block && this.mountPoint && this.mountPoint.parentNode) {
        block.classList.remove('aq-native-form');
        this.mountPoint.parentNode.insertBefore(block, this.mountPoint);
        this.mountPoint.remove();
        this.mountPoint = null;
      }
      Array.from(this.form.elements).forEach(input => {
        if (input.getAttribute('data-quiz-bridge') === this.selector &&
          [this.fieldName, this.fieldName + 'Source', this.fieldName + 'ContactChannel'].includes(input.name)) input.remove();
      });
      this.form = null;
    }
  }
  global.TildaQuizFormBridge = TildaQuizFormBridge;
})(window);
