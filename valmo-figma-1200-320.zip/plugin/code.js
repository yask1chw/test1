"use strict";
const imageCache = new Map();
const fontCache = new Map();
const iconCache = new Map();
const conversion = new Map();
let cancelled = false, run = false, current = null;
figma.showUI(__html__, { width: 520, height: 700, themeColors: true });
const post = (message) => figma.ui.postMessage(message);
const rgb = (c) => ({ r: c.r, g: c.g, b: c.b });
const solid = (c) => { var _a; return ({ type: 'SOLID', color: rgb(c), opacity: (_a = c.a) !== null && _a !== void 0 ? _a : 1 }); };
function waitUI(bytes, white) {
    const id = Math.random().toString(36).slice(2);
    return new Promise((resolve, reject) => { const timer = setTimeout(() => { conversion.delete(id); reject(Error('Преобразование изображения прервано.')); }, 45000); conversion.set(id, { resolve, reject, timer }); post({ type: 'convert-image', id, bytes: Array.from(bytes), white }); });
}
async function imageFromBytes(bytes, white) {
    const converted = await waitUI(bytes, white);
    const image = figma.createImage(converted);
    const size = await image.getSizeAsync();
    return { hash: image.hash, ...size };
}
async function loadAsset(asset) {
    const cached = imageCache.get(asset.id);
    if (cached)
        return cached;
    let ready;
    if (/\.svg(?:\?|$)/i.test(asset.url)) {
        const response = await fetch(asset.url);
        if (!response.ok)
            throw Error('HTTP ' + response.status);
        const raw = await response.text();
        if (!/<svg[\s>]/i.test(raw))
            throw Error('URL не вернул SVG.');
        const node = figma.createNodeFromSvg(raw);
        node.x = -100000;
        node.y = -100000;
        try {
            if (asset.white)
                node.findAll(n => 'fills' in n).forEach(n => { var _a; const shape = n; if (Array.isArray(shape.fills) && shape.fills.length)
                    shape.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }]; if ((_a = shape.strokes) === null || _a === void 0 ? void 0 : _a.length)
                    shape.strokes = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }]; });
            const scale = Math.min(3, 4096 / Math.max(node.width, node.height));
            const bytes = await node.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: scale } });
            const image = figma.createImage(bytes);
            ready = { hash: image.hash, ...await image.getSizeAsync() };
        }
        finally {
            node.remove();
        }
    }
    else {
        try {
            const image = await figma.createImageAsync(asset.url);
            ready = asset.white ? await imageFromBytes(await image.getBytesAsync(), true) : { hash: image.hash, ...await image.getSizeAsync() };
        }
        catch (_) {
            const response = await fetch(asset.url);
            if (!response.ok)
                throw Error('HTTP ' + response.status);
            ready = await imageFromBytes(new Uint8Array(await response.arrayBuffer()), asset.white);
        }
    }
    imageCache.set(asset.id, ready);
    return ready;
}
function fontWeight(style) { const s = style.toLowerCase().replace(/[ -]/g, ''); return s.includes('black') ? 900 : s.includes('extrabold') ? 800 : s.includes('semibold') ? 600 : s.includes('bold') ? 700 : s.includes('medium') ? 500 : s.includes('extralight') ? 200 : s.includes('light') ? 300 : s.includes('thin') ? 100 : 400; }
async function loadFonts(requests) {
    const all = await figma.listAvailableFontsAsync();
    const missing = [];
    for (const request of requests) {
        const key = request.family + ':' + request.weight;
        if (fontCache.has(key))
            continue;
        const candidates = all.map(f => f.fontName).filter(f => f.family.toLowerCase() === request.family.toLowerCase() && !/italic/i.test(f.style));
        candidates.sort((a, b) => Math.abs(fontWeight(a.style) - request.weight) - Math.abs(fontWeight(b.style) - request.weight));
        if (!candidates.length) {
            missing.push(request.family);
            continue;
        }
        await figma.loadFontAsync(candidates[0]);
        fontCache.set(key, candidates[0]);
    }
    if (missing.length)
        throw Error('Установите шрифты: ' + Array.from(new Set(missing)).join(', '));
}
async function preflight(assets, fonts) {
    await loadFonts(fonts);
    const failures = [];
    let cursor = 0, done = 0;
    async function worker() { while (cursor < assets.length && !cancelled) {
        const asset = assets[cursor++];
        let timer;
        try {
            await Promise.race([loadAsset(asset), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('Timeout: изображение не загрузилось за 35 секунд.')), 35000); })]);
        }
        catch (e) {
            failures.push({ id: asset.id, url: asset.url, error: String(e) });
        }
        finally {
            if (timer !== undefined)
                clearTimeout(timer);
        }
        done++;
        post({ type: 'asset-progress', done, total: assets.length, failed: failures.length });
    } }
    await Promise.all([worker(), worker(), worker()]);
    return failures;
}
function gradientPaint(g) {
    const radians = g.angle * Math.PI / 180, dx = Math.sin(radians), dy = -Math.cos(radians), sx = .5 - dx / 2, sy = .5 - dy / 2;
    return { type: 'GRADIENT_LINEAR', gradientStops: g.stops.map(s => { var _a; return ({ position: Math.min(1, Math.max(0, s.position)), color: { ...rgb(s.color), a: (_a = s.color.a) !== null && _a !== void 0 ? _a : 1 } }); }), gradientTransform: [[dx, dy, -dx * sx - dy * sy], [-dy, dx, dy * sx - dx * sy]] };
}
async function makeNode(item, parent) {
    var _a;
    let node;
    if (item.type === 'TEXT') {
        const text = figma.createText();
        parent.appendChild(text);
        const font = fontCache.get((item.font || 'Manrope') + ':' + (item.weight || 400));
        if (!font)
            throw Error('Шрифт не загружен.');
        text.fontName = font;
        text.fontSize = item.fontSize || 14;
        text.lineHeight = { unit: 'PIXELS', value: item.lineHeight || ((item.fontSize || 14) * 1.3) };
        text.letterSpacing = { unit: 'PIXELS', value: item.letterSpacing || 0 };
        text.characters = item.text || '';
        text.fills = item.color ? [solid(item.color)] : [];
        text.textAutoResize = 'HEIGHT';
        text.resize(Math.max(1, item.w), Math.max(1, item.h));
        node = text;
    }
    else if (item.type === 'SVG') {
        const key = (item.svg || '') + ':' + item.w + ':' + item.h;
        let hash = iconCache.get(key);
        if (!hash) {
            const svg = figma.createNodeFromSvg(item.svg || '<svg/>');
            svg.x = -100000;
            svg.y = -100000;
            try {
                svg.rescale(Math.min(Math.max(1, item.w) / svg.width, Math.max(1, item.h) / svg.height));
                const bytes = await svg.exportAsync({ format: 'PNG', constraint: { type: 'SCALE', value: 2 } });
                hash = figma.createImage(bytes).hash;
                iconCache.set(key, hash);
            }
            finally {
                svg.remove();
            }
        }
        const image = figma.createRectangle();
        parent.appendChild(image);
        image.resize(Math.max(1, item.w), Math.max(1, item.h));
        image.fills = [{ type: 'IMAGE', imageHash: hash, scaleMode: 'FIT' }];
        image.strokes = [];
        node = image;
    }
    else {
        const shape = item.type === 'ELLIPSE' ? figma.createEllipse() : figma.createRectangle();
        parent.appendChild(shape);
        shape.resize(Math.max(.1, item.w), Math.max(.1, item.h));
        const fills = [];
        if (item.gradient)
            fills.push(gradientPaint(item.gradient));
        if (item.fill)
            fills.push(solid(item.fill));
        if (item.type === 'IMAGE') {
            const image = imageCache.get(item.assetId || '');
            if (!image)
                throw Error('Фото не загружено: ' + item.assetId);
            if (item.fit === 'FIT') {
                const scale = Math.min(item.w / image.width, item.h / image.height), width = image.width * scale, height = image.height * scale;
                const p = (item.position || '50% 50%').split(' '), px = parseFloat(p[0]) / 100 || 0, py = parseFloat(p[1]) / 100 || 0;
                item = { ...item, x: item.x + (item.w - width) * px, y: item.y + (item.h - height) * py, w: width, h: height };
                shape.resize(Math.max(.1, width), Math.max(.1, height));
            }
            fills.push({ type: 'IMAGE', imageHash: image.hash, scaleMode: 'FILL' });
        }
        shape.fills = fills;
        if (item.stroke && item.strokeWidth) {
            shape.strokes = [solid(item.stroke)];
            shape.strokeWeight = item.strokeWidth;
            shape.strokeAlign = 'INSIDE';
        }
        else
            shape.strokes = [];
        if ('cornerRadius' in shape)
            shape.cornerRadius = Math.min(item.radius || 0, item.w / 2, item.h / 2);
        node = shape;
    }
    node.name = item.name;
    node.x = item.x;
    node.y = item.y;
    node.opacity = Math.min(1, Math.max(0, (_a = item.opacity) !== null && _a !== void 0 ? _a : 1));
    if (item.href)
        node.setPluginData('sourceHref', item.href);
    if (item.type === 'EXTERNAL')
        node.setPluginData('tildaManualWidget', item.url || '');
    return node;
}
async function importScreen(screen) {
    if (!current)
        throw Error('Импорт не запущен.');
    let page = current.pages.get(screen.width);
    if (!page) {
        page = figma.createPage();
        page.name = 'VALMO / ' + screen.width + ' px';
        current.pages.set(screen.width, page);
    }
    await figma.setCurrentPageAsync(page);
    const index = current.index.get(screen.width) || 0, columns = screen.width === 1200 ? 8 : 16;
    if (index % columns === 0 && index > 0) {
        current.rowY.set(screen.width, (current.rowY.get(screen.width) || 0) + (current.rowH.get(screen.width) || 0) + 350);
        current.rowH.set(screen.width, 0);
    }
    const x = (index % columns) * (screen.width + 160), baseY = current.rowY.get(screen.width) || 0;
    const state = screen.variant !== 'Основной вид';
    let localY = 0;
    for (let i = 0; i < screen.blocks.length; i++) {
        if (cancelled)
            break;
        const block = screen.blocks[i], frame = figma.createFrame();
        page.appendChild(frame);
        frame.name = screen.route + ' / ' + screen.variant + ' / ' + String(i + 1).padStart(2, '0') + ' ' + block.name + ' / ' + screen.width;
        frame.x = x;
        frame.y = baseY + (state ? localY : block.y);
        frame.resize(screen.width, Math.max(1, block.height));
        frame.fills = [{ type: 'SOLID', color: { r: .985, g: .984, b: .98 } }];
        frame.clipsContent = true;
        frame.setPluginData('sourceRoute', screen.route);
        frame.setPluginData('viewport', String(screen.width));
        frame.setPluginData('tildaImport', 'root-frame');
        for (let j = 0; j < block.nodes.length; j++) {
            await makeNode(block.nodes[j], frame);
            current.nodes++;
            if (j % 200 === 199)
                await new Promise(resolve => setTimeout(resolve, 0));
        }
        localY += block.height;
        current.frames++;
    }
    current.index.set(screen.width, index + 1);
    current.rowH.set(screen.width, Math.max(current.rowH.get(screen.width) || 0, state ? localY : screen.height));
    post({ type: 'screen-done', route: screen.route, variant: screen.variant, width: screen.width, frames: current.frames, nodes: current.nodes });
}
figma.ui.onmessage = async (message) => {
    if (message.type === 'converted') {
        const pending = conversion.get(message.id);
        if (!pending)
            return;
        clearTimeout(pending.timer);
        conversion.delete(message.id);
        if (message.error)
            pending.reject(Error(message.error));
        else
            pending.resolve(new Uint8Array(message.bytes));
        return;
    }
    if (message.type === 'local-assets') {
        try {
            for (const asset of message.assets) {
                const image = figma.createImage(new Uint8Array(asset.bytes));
                imageCache.set(asset.id, { hash: image.hash, ...await image.getSizeAsync() });
            }
            post({ type: 'local-assets-ready', count: message.assets.length, id: message.id });
        }
        catch (e) {
            post({ type: 'error', message: String(e) });
        }
        return;
    }
    if (message.type === 'cancel') {
        cancelled = true;
        return;
    }
    try {
        if (message.type === 'start') {
            if (run)
                return;
            run = true;
            cancelled = false;
            const failures = await preflight(message.assets, message.fonts);
            if (failures.length || cancelled) {
                run = false;
                post({ type: 'preflight-failed', failures, cancelled });
                return;
            }
            current = { pages: new Map(), index: new Map(), rowY: new Map(), rowH: new Map(), frames: 0, nodes: 0 };
            post({ type: 'ready-for-screen' });
        }
        else if (message.type === 'screen') {
            if (cancelled) {
                run = false;
                post({ type: 'cancelled', frames: current === null || current === void 0 ? void 0 : current.frames });
                return;
            }
            await importScreen(message.screen);
            post({ type: 'ready-for-screen' });
        }
        else if (message.type === 'finish') {
            run = false;
            const page = (current === null || current === void 0 ? void 0 : current.pages.get(1200)) || (current === null || current === void 0 ? void 0 : current.pages.get(320));
            if (page) {
                await figma.setCurrentPageAsync(page);
                const first = page.children.find(n => n.type === 'FRAME');
                if (first) {
                    figma.currentPage.selection = [first];
                    figma.viewport.scrollAndZoomIntoView([first]);
                }
            }
            post({ type: 'finished', frames: current === null || current === void 0 ? void 0 : current.frames, nodes: current === null || current === void 0 ? void 0 : current.nodes, cancelled });
            figma.notify(cancelled ? 'Импорт остановлен.' : 'Макет создан. Фреймы 1200 и 320 px, плоская структура.');
        }
    }
    catch (e) {
        run = false;
        post({ type: 'error', message: String(e) });
    }
};
