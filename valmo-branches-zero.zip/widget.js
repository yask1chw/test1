(function () {
  'use strict';
  // Replace this one value with the anchor of your Tilda popup.
  var CONFIG = {
    popupLink: '#popup:valmo-branch',
    phoneLabel: '8 800 777-54-29',
    phoneHref: 'tel:88007775429',
    hoverDelay: 280,
    stickyTop: 96,
    autoHeightZeroBlock: true
  };

  function normalize(text) {
    return String(text || '').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е')
      .replace(/[^a-zа-я0-9]+/gi, ' ').trim().replace(/\s+/g, ' ');
  }
  function mount(root) {
    if (root.dataset.vbmReady === 'true') return;
    root.dataset.vbmReady = 'true';
    var cards = Array.from(root.querySelectorAll('[data-vbm-branch]'));
    var input = root.querySelector('[data-vbm-search]');
    var clear = root.querySelector('[data-vbm-clear]');
    var counter = root.querySelector('[data-vbm-count]');
    var empty = root.querySelector('[data-vbm-empty]');
    var frame = root.querySelector('[data-vbm-map]');
    var message = root.querySelector('[data-vbm-map-message]');
    var info = root.querySelector('[data-vbm-map-info]');
    var mapCity = root.querySelector('[data-vbm-map-city]');
    var mapAddress = root.querySelector('[data-vbm-map-address]');
    var yandexLink = root.querySelector('[data-vbm-yandex]');
    var googleLink = root.querySelector('[data-vbm-google]');
    var branches = cards.map(function (card) {
      var branch = {
        id: card.dataset.vbmBranch,
        city: card.querySelector('.vbm-city').textContent.trim(),
        address: card.querySelector('.vbm-address').textContent.trim(),
        phone: CONFIG.phoneLabel,
        phoneHref: CONFIG.phoneHref,
        card: card
      };
      branch.search = normalize(branch.city + ' ' + branch.address + ' ' + card.dataset.vbmAliases);
      return branch;
    });
    var selectedId = branches[0].id;
    var lastMapId = null;
    var hoverTimer = 0;
    var mapTimer = 0;
    var resizeFrame = 0;
    var mapVisible = !window.IntersectionObserver;
    var hoverAllowed = window.matchMedia('(hover:hover) and (pointer:fine)');
    root.style.setProperty('--vbm-sticky', CONFIG.stickyTop + 'px');
    root.querySelectorAll('.vbm-contact').forEach(function (a) { a.setAttribute('href', CONFIG.popupLink); });
    root.querySelectorAll('.vbm-phone').forEach(function (a) { a.setAttribute('href', CONFIG.phoneHref); a.textContent = CONFIG.phoneLabel; });

    function getBranch(id) { return branches.find(function (b) { return b.id === id; }); }
    function queryFor(branch) { return 'Россия, ' + branch.address; }
    function publicBranch(branch) {
      return branch ? { id:branch.id, city:branch.city, address:branch.address, phone:branch.phone, phoneHref:branch.phoneHref } : null;
    }
    function requestFit() {
      if (resizeFrame) return;
      resizeFrame = window.requestAnimationFrame(function () { resizeFrame = 0; fitZeroBlock(); });
    }
    function heightStyle(node, height) {
      if (node && node.style.getPropertyValue('height') !== height + 'px') node.style.setProperty('height', height + 'px', 'important');
    }
    function fitZeroBlock() {
      if (!CONFIG.autoHeightZeroBlock) return;
      var elem = root.closest('.tn-elem');
      var atom = root.closest('.tn-atom');
      var artboard = root.closest('.t396__artboard');
      if (!elem || !atom || !artboard) return;
      var height = Math.ceil(root.offsetHeight);
      heightStyle(atom, height);
      heightStyle(elem, height);
      // A dedicated Zero Block prevents resizing other designer-positioned content.
      var others = Array.from(artboard.querySelectorAll('.tn-elem')).filter(function (other) {
        return other !== elem && !other.contains(elem) && !elem.contains(other) && other.getClientRects().length && getComputedStyle(other).display !== 'none';
      });
      if (others.length) return;
      var bounds = artboard.getBoundingClientRect();
      var rootBounds = root.getBoundingClientRect();
      var artScale = artboard.offsetHeight ? bounds.height / artboard.offsetHeight : 1;
      if (!Number.isFinite(artScale) || artScale <= 0) artScale = 1;
      var needed = Math.max(1, Math.ceil((rootBounds.bottom - bounds.top) / artScale));
      heightStyle(artboard, needed);
      Array.from(artboard.children).filter(function (n) {
        return n.classList.contains('t396__carrier') || n.classList.contains('t396__filter');
      }).forEach(function (n) { heightStyle(n, needed); });
    }
    function updateMap(branch) {
      if (!branch) {
        window.clearTimeout(mapTimer);
        lastMapId = null;
        frame.hidden = true;
        frame.removeAttribute('src');
        frame.removeAttribute('aria-busy');
        info.hidden = true;
        message.textContent = 'По этому запросу филиалов нет. Измените город или сбросьте поиск.';
        message.hidden = false;
        return;
      }
      info.hidden = false;
      frame.hidden = false;
      var query = queryFor(branch);
      mapCity.textContent = branch.city;
      mapAddress.textContent = branch.address;
      yandexLink.href = 'https://yandex.ru/maps/?text=' + encodeURIComponent(query);
      googleLink.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(query);
      if (lastMapId === branch.id) return;
      window.clearTimeout(mapTimer);
      lastMapId = branch.id;
      frame.title = 'Карта — филиал VALMO RUS: ' + branch.city;
      frame.setAttribute('aria-busy', 'true');
      message.textContent = 'Загружается карта: ' + branch.city + '…';
      message.hidden = false;
      // Full street address; no invented coordinates or API key required.
      var url = 'https://www.google.com/maps?q=' + encodeURIComponent(query) + '&output=embed&hl=ru';
      if (frame.getAttribute('src') !== url) frame.setAttribute('src', url);
      watchMap();
    }
    function watchMap() {
      window.clearTimeout(mapTimer);
      if (!mapVisible || !lastMapId || !frame.hasAttribute('aria-busy')) return;
      var expectedId = lastMapId;
      mapTimer = window.setTimeout(function () {
        if (lastMapId !== expectedId) return;
        message.textContent = 'Карта загружается дольше обычного. Можно открыть этот адрес в Яндекс Картах или Google Картах по ссылкам ниже.';
        message.hidden = false;
        frame.removeAttribute('aria-busy');
      }, 12000);
    }

    function selectBranch(id, immediate) {
      var branch = getBranch(id);
      if (!branch || branch.card.hidden) return;
      selectedId = id;
      root.dataset.vbmSelected = id;
      branches.forEach(function (b) {
        var active = b.id === id;
        b.card.classList.toggle('is-selected', active);
        b.card.querySelector('[data-vbm-select]').setAttribute('aria-pressed', String(active));
      });
      window.clearTimeout(hoverTimer);
      if (immediate) updateMap(branch);
      else hoverTimer = window.setTimeout(function () { updateMap(getBranch(selectedId)); }, CONFIG.hoverDelay);
    }
    function applySearch() {
      window.clearTimeout(hoverTimer);
      var words = normalize(input.value).split(' ').filter(Boolean);
      var filtered = branches.filter(function (branch) {
        var matches = words.every(function (word) { return branch.search.indexOf(word) !== -1; });
        branch.card.hidden = !matches;
        return matches;
      });
      clear.hidden = input.value.length === 0;
      counter.textContent = words.length ? 'Найдено площадок: ' + filtered.length + ' из ' + branches.length : 'Площадки продаж: ' + branches.length;
      empty.hidden = filtered.length !== 0;
      if (filtered.length) {
        var retained = filtered.find(function (b) { return b.id === selectedId; });
        selectBranch((retained || filtered[0]).id, true);
      } else {
        selectedId = null;
        root.dataset.vbmSelected = '';
        branches.forEach(function (b) { b.card.classList.remove('is-selected'); b.card.querySelector('[data-vbm-select]').setAttribute('aria-pressed', 'false'); });
        updateMap(null);
      }
      requestFit();
    }
    function reset() { input.value = ''; applySearch(); input.focus({ preventScroll:true }); }
    input.addEventListener('input', applySearch);
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { event.preventDefault(); reset(); }
      if (event.key === 'Enter') {
        event.preventDefault();
        var branch = getBranch(selectedId);
        if (branch) branch.card.querySelector('[data-vbm-select]').focus();
      }
    });
    clear.addEventListener('click', reset);
    root.querySelector('[data-vbm-reset]').addEventListener('click', reset);
    branches.forEach(function (branch) {
      branch.card.addEventListener('pointerenter', function (event) {
        if (event.pointerType === 'mouse' && hoverAllowed.matches) selectBranch(branch.id, false);
      });
      branch.card.querySelector('[data-vbm-select]').addEventListener('click', function () { selectBranch(branch.id, true); });
      branch.card.addEventListener('focusin', function () { selectBranch(branch.id, true); });
      branch.card.querySelector('.vbm-contact').addEventListener('click', function () {
        selectBranch(branch.id, true);
        root.dispatchEvent(new CustomEvent('valmo:branch-contact', { bubbles:true, detail:publicBranch(branch) }));
        // Do not preventDefault: Tilda handles #popup:... through its native link handler.
      });
    });
    frame.addEventListener('load', function () {
      if (!lastMapId) return;
      window.clearTimeout(mapTimer);
      frame.removeAttribute('aria-busy');
      message.hidden = true;
      // An iframe load is not proof that a third-party map rendered successfully.
    });
    frame.addEventListener('error', function () {
      if (!lastMapId) return;
      window.clearTimeout(mapTimer);
      frame.removeAttribute('aria-busy');
      message.textContent = 'Не удалось загрузить карту. Откройте адрес по ссылке ниже.';
      message.hidden = false;
    });
    if (window.IntersectionObserver) {
      var mapObserver = new IntersectionObserver(function (entries) {
        mapVisible = entries.some(function (entry) { return entry.isIntersecting; });
        watchMap();
      });
      mapObserver.observe(frame);
    }
    if (window.ResizeObserver) {
      var observer = new ResizeObserver(requestFit);
      observer.observe(root);
    }
    window.addEventListener('resize', function () { requestFit(); window.setTimeout(requestFit, 200); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(requestFit);
    root.vbm = {
      select: function (id) { selectBranch(id, true); },
      search: function (text) { input.value = String(text || ''); applySearch(); },
      selected: function () { return publicBranch(getBranch(selectedId)); }
    };
    applySearch();
    requestFit();
  }
  function boot() { document.querySelectorAll('[data-valmo-branches]').forEach(mount); }
  boot();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once:true });
})();
