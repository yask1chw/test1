const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root='/workspace/figma-home-catalog-v4';const data=JSON.parse(fs.readFileSync(root+'/layout.json'));
let nodes=[],messages=[],page,images=new Map(),counter=0,allowNetwork=false;
class Node{
 constructor(type){this.id=String(++counter);this.type=type;this.children=[];this.parent=null;this.width=24;this.height=24;this.x=0;this.y=0;this.fills=[];this.strokes=[];this.meta={};nodes.push(this);}
 appendChild(node){if(node.parent)node.parent.children=node.parent.children.filter(n=>n!==node);this.children.push(node);node.parent=this;}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);this.parent=null;this.removed=true;}
 resize(w,h){assert(Number.isFinite(w)&&Number.isFinite(h)&&w>0&&h>0);this.width=w;this.height=h;}
 rescale(scale){this.width*=scale;this.height*=scale;}
 setPluginData(k,v){this.meta[k]=v;}
 findAll(predicate){const all=[];function go(n){for(const child of n.children){if(predicate(child))all.push(child);go(child)}}go(this);return all;}
 async exportAsync(){return new Uint8Array([137,80,78,71]);}
}
const initial=new Node('PAGE');page=initial;
function make(type){const n=new Node(type);page.appendChild(n);return n}
function image(){const hash='image-'+images.size;const img={hash,getSizeAsync:async()=>({width:600,height:400}),getBytesAsync:async()=>new Uint8Array([137,80,78,71])};images.set(hash,img);return img}
const fontNames=['Regular','Medium','SemiBold','Bold','ExtraBold'].flatMap(style=>['Manrope','Oswald'].map(family=>({fontName:{family,style}})));
const figma={ui:{onmessage:null,postMessage(m){messages.push(m);if(m.type==='convert-image')setTimeout(()=>figma.ui.onmessage({type:'converted',id:m.id,bytes:[137,80,78,71]}),0);}},showUI(){},listAvailableFontsAsync:async()=>fontNames,loadFontAsync:async()=>{},createImageAsync:async()=>{if(!allowNetwork)throw Error('fixture network denied');return image()},createImage:()=>image(),getImageByHash:hash=>images.get(hash),createNodeFromSvg:()=>make('FRAME'),createText:()=>make('TEXT'),createRectangle:()=>make('RECTANGLE'),createEllipse:()=>make('ELLIPSE'),createFrame:()=>make('FRAME'),createPage:()=>new Node('PAGE'),setCurrentPageAsync:async p=>{page=p;figma.currentPage=p},currentPage:initial,viewport:{scrollAndZoomIntoView(){}},notify(){}};
const context={figma,__html__:'UI fixture',fetch:async()=>{if(!allowNetwork)throw Error('fixture network denied');return {ok:true,text:async()=>'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><path d="M0 0L24 24"/></svg>',arrayBuffer:async()=>new ArrayBuffer(4)}},setTimeout,clearTimeout,console,Uint8Array,Map,Math,Promise};
vm.runInNewContext(fs.readFileSync(root+'/plugin/code.js','utf8'),context);
(async()=>{
 const fonts=[...new Map(data.screens.flatMap(s=>s.blocks.flatMap(b=>b.nodes.filter(n=>n.type==='TEXT').map(n=>[n.font+':'+n.weight,{family:n.font,weight:n.weight}])))).values()];
 await figma.ui.onmessage({type:'start',assets:[data.assets[0]],fonts});assert(messages.some(m=>m.type==='preflight-failed'));assert(!nodes.some(n=>n.meta.tildaImport),'frames created despite missing photos');
 allowNetwork=true;messages=[];await figma.ui.onmessage({type:'start',assets:data.assets,fonts});assert(messages.some(m=>m.type==='ready-for-screen'));
 for(const screen of data.screens)await figma.ui.onmessage({type:'screen',screen});
 await figma.ui.onmessage({type:'finish'});assert(messages.some(m=>m.type==='finished'));
 const frames=nodes.filter(n=>!n.removed&&n.meta.tildaImport);const expected=data.screens.reduce((a,s)=>a+s.blocks.length,0);assert.equal(frames.length,expected);
 let count=0,imagesUsed=0,maxDepth=0,slots=0;
 function arrange(n){if(n.type!=='FRAME')return;let pos=n.layoutMode==='VERTICAL'?(n.paddingTop||0):(n.paddingLeft||0);const v=n.layoutMode==='VERTICAL';const space=n.itemSpacing||0;const sum=n.children.reduce((a,c)=>a+(v?c.height:c.width),0)+Math.max(0,n.children.length-1)*space;const main=v?n.height-(n.paddingTop||0)-(n.paddingBottom||0):n.width-(n.paddingLeft||0)-(n.paddingRight||0);if(n.primaryAxisAlignItems==='CENTER')pos+=(main-sum)/2;if(n.primaryAxisAlignItems==='MAX')pos+=main-sum;
 for(const c of n.children){if(v){c.y=pos;c.x=n.counterAxisAlignItems==='CENTER'?(n.width-c.width)/2:n.counterAxisAlignItems==='MAX'?n.width-c.width:0;pos+=c.height+space;}else{c.x=pos;c.y=n.counterAxisAlignItems==='CENTER'?(n.height-c.height)/2:0;pos+=c.width+space;}arrange(c);}}
 function walk(n,depth,x,y){maxDepth=Math.max(maxDepth,depth);if(n.meta.sourceBox){const source=JSON.parse(n.meta.sourceBox);assert(Math.abs(x-source.x)<.001,'x shifted '+n.name);assert(Math.abs(y-source.y)<.001,'y shifted '+n.name);assert(Math.abs(n.width-source.w)<.001);assert(Math.abs(n.height-source.h)<.001);slots++;}if(n.fills.some(p=>p.type==='IMAGE'))imagesUsed++;for(const c of n.children){assert(c.layoutPositioning==='AUTO');count++;walk(c,depth+1,x+c.x,y+c.y);}}
 for(const frame of frames){arrange(frame);walk(frame,1,0,0);}assert(maxDepth<=6);assert(slots>1000);assert(imagesUsed>100);
 const report={frames:frames.length,nodes:count,sourceBoxesPreserved:slots,zeroAbsoluteChildren:true,imageLayers:imagesUsed,maxSceneLayerDepth:maxDepth,widths:[1200,320],missingPhotosBlockCreation:true,api:'Figma API mock + real TypeScript typings; live Figma/Tilda not executed',originalPhotoNetwork:'fixture, not a live download'};
 fs.writeFileSync(root+'/validation-plugin.json',JSON.stringify(report,null,2));console.log(report);
})().catch(e=>{console.error(e);process.exitCode=1});
