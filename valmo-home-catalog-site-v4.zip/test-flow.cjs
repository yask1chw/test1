const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root='/workspace/figma-home-catalog';const data=JSON.parse(fs.readFileSync(root+'/layout.json'));
let nodes=[],messages=[],page,images=new Map(),counter=0,allowNetwork=false;
class Node{
 constructor(type){this.id=String(++counter);this.type=type;this.children=[];this.parent=null;this.width=24;this.height=24;this.x=0;this.y=0;this.fills=[];this.strokes=[];this.meta={};nodes.push(this);}
 appendChild(node){if(node.parent)node.parent.children=node.parent.children.filter(n=>n!==node);this.children.push(node);node.parent=this;}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);this.parent=null;this.removed=true;}
 resize(w,h){assert(Number.isFinite(w)&&Number.isFinite(h)&&w>0&&h>0);this.width=w;this.height=h;}
 rescale(scale){this.width*=scale;this.height*=scale;}
 setPluginData(k,v){this.meta[k]=v;}
 findAll(predicate){const all=[];function go(n){for(const child of n.children){if(predicate(child))all.push(child);go(child)}}go(this);return all;}
 async exportAsync(){return new Uint8Array([137,80,78,71]);}
}
const initial=new Node('PAGE');page=initial;
function make(type){const n=new Node(type);page.appendChild(n);return n}
function image(){const hash='image-'+images.size;const img={hash,getSizeAsync:async()=>({width:600,height:400}),getBytesAsync:async()=>new Uint8Array([137,80,78,71])};images.set(hash,img);return img}
const fontNames=['Regular','Medium','SemiBold','Bold','ExtraBold'].flatMap(style=>['Manrope','Oswald'].map(family=>({fontName:{family,style}})));
const figma={ui:{onmessage:null,postMessage(m){messages.push(m);if(m.type==='convert-image')setTimeout(()=>figma.ui.onmessage({type:'converted',id:m.id,bytes:[137,80,78,71]}),0);}},showUI(){},listAvailableFontsAsync:async()=>fontNames,loadFontAsync:async()=>{},createImageAsync:async()=>{if(!allowNetwork)throw Error('fixture network denied');return image()},createImage:()=>image(),getImageByHash:hash=>images.get(hash),createNodeFromSvg:()=>make('FRAME'),createText:()=>make('TEXT'),createRectangle:()=>make('RECTANGLE'),createEllipse:()=>make('ELLIPSE'),createFrame:()=>make('FRAME'),createPage:()=>new Node('PAGE'),setCurrentPageAsync:async p=>{page=p;figma.currentPage=p},currentPage:initial,viewport:{scrollAndZoomIntoView(){}},notify(){}};
const context={figma,__html__:'UI fixture',fetch:async()=>{if(!allowNetwork)throw Error('fixture network denied');return {ok:true,text:async()=>'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><path d="M0 0L24 24"/></svg>',arrayBuffer:async()=>new ArrayBuffer(4)}},setTimeout,clearTimeout,console,Uint8Array,Map,Math,Promise};
vm.runInNewContext(fs.readFileSync(root+'/plugin/code.js','utf8'),context);
(async()=>{
 const fonts=[...new Map(data.screens.flatMap(s=>s.blocks.flatMap(b=>b.nodes.filter(n=>n.type==='TEXT').map(n=>[n.font+':'+n.weight,{family:n.font,weight:n.weight}])))).values()];
 await figma.ui.onmessage({type:'start',assets:[data.assets[0]],fonts});assert(messages.some(m=>m.type==='preflight-failed'));assert(!nodes.some(n=>n.meta.tildaImport),'frames created despite missing photos');
 allowNetwork=true;messages=[];await figma.ui.onmessage({type:'start',assets:data.assets,fonts});assert(messages.some(m=>m.type==='ready-for-screen'));
 for(const screen of data.screens)await figma.ui.onmessage({type:'screen',screen});
 await figma.ui.onmessage({type:'finish'});assert(messages.some(m=>m.type==='finished'));
 const frames=nodes.filter(n=>!n.removed&&n.meta.tildaImport);const expected=data.screens.reduce((a,s)=>a+s.blocks.length,0);assert.equal(frames.length,expected);
 let count=0,imagesUsed=0,maxDepth=0;const texts=[];
 function walk(n,depth){maxDepth=Math.max(maxDepth,depth);if(n.type==='TEXT')texts.push(n);if(n.fills.some(p=>p.type==='IMAGE'))imagesUsed++;if(n.type==='FRAME'){assert(['VERTICAL','HORIZONTAL'].includes(n.layoutMode));assert(n.width>=16);}
 for(const child of n.children){assert(child.layoutPositioning==='AUTO');count++;walk(child,depth+1);}}
 for(const frame of frames){assert([1200,320].includes(frame.width));walk(frame,1)}
 assert(maxDepth<=6);const sourceTexts=data.screens.flatMap(s=>s.blocks.flatMap(b=>b.nodes.filter(n=>n.type==='TEXT')));
 const expectedWidths=sourceTexts.map(n=>n.text+':'+n.w.toFixed(3)).sort();const actualWidths=texts.map(n=>n.characters+':'+n.width.toFixed(3)).sort();assert.deepEqual(actualWidths,expectedWidths,'text lost or squeezed');assert(imagesUsed>20);
 const report={frames:frames.length,nodes:count,textWidthsPreserved:true,zeroAbsoluteChildren:true,imageLayers:imagesUsed,maxSceneLayerDepth:maxDepth,widths:[1200,320],missingPhotosBlockCreation:true,api:'Figma API mock + real TypeScript typings; live Figma/Tilda not executed',originalPhotoNetwork:'fixture, not a live download'};
 fs.writeFileSync(root+'/validation-plugin.json',JSON.stringify(report,null,2));console.log(report);
})().catch(e=>{console.error(e);process.exitCode=1});
