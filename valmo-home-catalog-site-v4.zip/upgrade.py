from pathlib import Path
import json
P=Path(__file__).parent
p=P/'plugin/plugin.ts';s=p.read_text();a=s.index("    frame.layoutMode='VERTICAL'");b=s.index('    localY+=frame.height',a)
s=s[:a]+'''    // Overlap is expressed with negative Auto Layout spacing, not absolute children.
    frame.layoutMode='VERTICAL';frame.primaryAxisSizingMode='FIXED';frame.counterAxisSizingMode='FIXED';frame.resize(screen.width,block.height);frame.paddingLeft=0;frame.paddingRight=0;frame.paddingTop=0;frame.paddingBottom=0;frame.itemSpacing=-block.height;frame.itemReverseZIndex=false;
    function container(parent:FrameNode,w:number,h:number,mode:'VERTICAL'|'HORIZONTAL',name:string){const f=figma.createFrame();parent.appendChild(f);f.name=name;f.layoutMode=mode;f.primaryAxisSizingMode='FIXED';f.counterAxisSizingMode='FIXED';f.resize(Math.max(1,w),Math.max(1,h));f.layoutPositioning='AUTO';f.fills=[];f.strokes=[];f.clipsContent=false;return f;}
    function spacer(parent:FrameNode){const n=figma.createRectangle();parent.appendChild(n);n.name='spacing';n.resize(1,1);n.fills=[];n.strokes=[];n.layoutPositioning='AUTO';}
    const source=block.nodes,skip=new Set<number>();
    for(let j=0;j<source.length;j++){
      if(skip.has(j))continue;const item=source[j];
      const isButton=item.type==='RECT'&&/^(button|a) \\/ фон$/.test(item.name)&&item.w>=28&&item.w<=500&&item.h>=28&&item.h<=85;
      const children=isButton?source.map((n,k)=>({n,k})).filter(({n,k})=>k>j&&!skip.has(k)&&(n.type==='TEXT'||n.type==='SVG')&&n.x>=item.x-1&&n.y>=item.y-1&&n.x+n.w<=item.x+item.w+2&&n.y+n.h<=item.y+item.h+2):[];
      const button=isButton&&children.length>0&&children.length<=5;
      const layer=container(frame,screen.width,block.height,'VERTICAL',(button?'button':'layer')+' / '+item.name);layer.itemSpacing=item.y-1;spacer(layer);
      const row=container(layer,screen.width,Math.max(1,item.h),'HORIZONTAL','position');row.itemSpacing=item.x-1;spacer(row);
      const holder=container(row,item.w,item.h,'VERTICAL','content');holder.primaryAxisAlignItems='CENTER';holder.counterAxisAlignItems='CENTER';
      if(item.type==='IMAGE'){
        const position=(item.position||'50% 50%').split(' ');holder.counterAxisAlignItems=position[0]==='0%'?'MIN':position[0]==='100%'?'MAX':'CENTER';holder.primaryAxisAlignItems=position[1]==='0%'?'MIN':position[1]==='100%'?'MAX':'CENTER';
      }
      if(button){
        const bg=container(holder,item.w,item.h,'HORIZONTAL','button');bg.primaryAxisAlignItems='CENTER';bg.counterAxisAlignItems='CENTER';bg.itemSpacing=8;bg.cornerRadius=Math.min(item.radius||0,item.h/2);bg.fills=item.fill?[solid(item.fill)]:[];if(item.stroke&&item.strokeWidth){bg.strokes=[solid(item.stroke)];bg.strokeWeight=item.strokeWidth;bg.strokeAlign='INSIDE';}
        for(const child of children.sort((a,b)=>a.n.x-b.n.x)){const n=await makeNode(child.n,bg);n.layoutPositioning='AUTO';skip.add(child.k);current!.nodes++;}
      }else{const n=await makeNode(item,holder);n.layoutPositioning='AUTO';current!.nodes++;}
      if(j%100===99)await new Promise<void>(resolve=>setTimeout(resolve,0));
    }
''' +s[b:]
s=s.replace("node.name=item.name;node.x=item.x;node.y=item.y;", "node.name=item.name;if(parent.layoutMode==='NONE'){node.x=item.x;node.y=item.y;}")
s=s.replace('VALMO FLEX v3 / ','VALMO SITE v4 / ');p.write_text(s)
p=P/'plugin/manifest.json';m=json.loads(p.read_text());m['name']='VALMO SITE v4 — композиция сайта';m['id']='valmo-site-layout-v4';p.write_text(json.dumps(m,ensure_ascii=False,indent=2))
d=json.loads((P/'layout.json').read_text())
for screen in d['screens']:
 for block in screen['blocks']:
  block.pop('flow',None);block.pop('surface',None)
(P/'layout.json').write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')))
