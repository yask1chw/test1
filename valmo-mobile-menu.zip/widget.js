(function () {
  'use strict';
  // Replace these defaults with the actual page/anchor links in your Tilda site.
  var CONFIG = {
    homeUrl: '/',
    catalogUrl: '/catalog',
    stockUrl: '/catalog?availability=in_stock',
    leasingUrl: '/#leasing',
    serviceUrl: '/#service',
    companyUrl: '/#about',
    contactsUrl: '/#branches',
    quotePopup: '#popup:valmo-kp',
    searchUrl: '/catalog',
    searchParam: 'q',
    phoneLabel: '8 (800) 777-54-29',
    phoneHref: 'tel:88007775429',
    logoImageUrl: ''
  };
  function mount() {
    var roots = Array.from(document.querySelectorAll('[data-valmo-mobile-menu]'));
    var existing = roots.find(function (r) { return r.dataset.vmmReady === 'true'; });
    roots.forEach(function (root) {
      if (root.dataset.vmmReady === 'true') return;
      if (existing) { root.remove(); return; }
      existing = root;
      root.dataset.vmmReady = 'true';
      // Escape the transform/overflow of the HTML element in Zero Block.
      document.body.appendChild(root);
      var panel = root.querySelector('[data-vmm-panel]');
      var closeButton = root.querySelector('[data-vmm-close]');
      var form = root.querySelector('[data-vmm-search]');
      var input = root.querySelector('[data-vmm-query]');
      var error = root.querySelector('[data-vmm-error]');
      var uid = 'vmm-dialog-' + Math.random().toString(36).slice(2,10);
      panel.id = uid;
      var isOpen = false;
      var opener = null;
      var savedScroll = null;
      var savedStyles = [];
      var background = [];
      var links = {home:'homeUrl',catalog:'catalogUrl',stock:'stockUrl',leasing:'leasingUrl',service:'serviceUrl',company:'companyUrl',contacts:'contactsUrl',quote:'quotePopup'};
      Object.keys(links).forEach(function (key) { root.querySelector('[data-vmm-link="'+key+'"]').setAttribute('href', CONFIG[links[key]]); });
      var phone = root.querySelector('[data-vmm-phone]');
      phone.href = CONFIG.phoneHref;
      phone.textContent = CONFIG.phoneLabel;
      form.action = CONFIG.searchUrl;
      input.name = CONFIG.searchParam;
      if (CONFIG.logoImageUrl) {
        var img = document.createElement('img');
        img.className = 'vmm-logo-image';
        img.src = CONFIG.logoImageUrl;
        img.alt = 'VALMO RUS';
        root.querySelector('[data-vmm-logo-content]').replaceChildren(img);
      }
      function isTriggerLink(link) {
        if (!link || link.tagName !== 'A') return false;
        var href = link.getAttribute('href') || '';
        if (href.trim() === '#menuopen') return true;
        try {
          var url = new URL(href, document.baseURI);
          return url.hash === '#menuopen' && url.origin === location.origin && url.pathname === location.pathname && url.search === location.search;
        } catch (_) { return false; }
      }
      function findTrigger(target) {
        if (!(target instanceof Element)) return null;
        var element = target.closest('[data-vmm-open], #menuopen');
        if (element && !root.contains(element)) return element;
        var link = target.closest('a[href]');
        return isTriggerLink(link) && !root.contains(link) ? link : null;
      }
      function updateTriggers() {
        document.querySelectorAll('a[href], #menuopen, [data-vmm-open]').forEach(function (element) {
          if (!isTriggerLink(element) && element.id !== 'menuopen' && !element.hasAttribute('data-vmm-open')) return;
          if (root.contains(element)) return;
          element.setAttribute('aria-controls', uid);
          element.setAttribute('aria-expanded', String(isOpen));
          element.setAttribute('aria-haspopup', 'dialog');
          if (!['A','BUTTON','INPUT'].includes(element.tagName)) {
            element.setAttribute('role', 'button');
            if (!element.hasAttribute('tabindex')) element.tabIndex = 0;
          }
        });
      }
      function rememberStyle(node, property, value) {
        savedStyles.push({node:node,property:property,value:node.style.getPropertyValue(property),priority:node.style.getPropertyPriority(property)});
        node.style.setProperty(property, value, 'important');
      }
      function lockPage() {
        savedScroll = {x:window.scrollX,y:window.scrollY};
        savedStyles = [];
        var gap = Math.max(0, window.innerWidth-document.documentElement.clientWidth);
        var padding = parseFloat(getComputedStyle(document.body).paddingRight) || 0;
        rememberStyle(document.documentElement, 'overflow', 'hidden');
        rememberStyle(document.body, 'overflow', 'hidden');
        rememberStyle(document.body, 'position', 'fixed');
        rememberStyle(document.body, 'top', -savedScroll.y+'px');
        rememberStyle(document.body, 'left', -savedScroll.x+'px');
        rememberStyle(document.body, 'width', '100%');
        rememberStyle(document.body, 'box-sizing', 'border-box');
        if (gap) rememberStyle(document.body, 'padding-right', padding+gap+'px');
        background = Array.from(document.body.children).filter(function (node) { return node!==root && !['STYLE','SCRIPT','LINK'].includes(node.tagName); }).map(function (node) {
          var record = {node:node,inert:node.inert,ariaHidden:node.getAttribute('aria-hidden'),nativeInert:'inert' in node};
          if (record.nativeInert) node.inert = true;
          else node.setAttribute('aria-hidden','true');
          return record;
        });
      }
      function unlockPage() {
        background.forEach(function (record) {
          if (record.nativeInert) record.node.inert=record.inert;
          else if (record.ariaHidden===null) record.node.removeAttribute('aria-hidden');
          else record.node.setAttribute('aria-hidden',record.ariaHidden);
        });
        background=[];
        savedStyles.reverse().forEach(function (record) {
          if (record.value) record.node.style.setProperty(record.property,record.value,record.priority);
          else record.node.style.removeProperty(record.property);
        });
        savedStyles=[];
        if (savedScroll) {
          var html=document.documentElement;
          var value=html.style.getPropertyValue('scroll-behavior'),priority=html.style.getPropertyPriority('scroll-behavior');
          html.style.setProperty('scroll-behavior','auto','important');
          window.scrollTo(savedScroll.x,savedScroll.y);
          if (value) html.style.setProperty('scroll-behavior',value,priority); else html.style.removeProperty('scroll-behavior');
          savedScroll=null;
        }
      }
      function clearMenuHash() {
        if (location.hash !== '#menuopen') return;
        try { history.replaceState(history.state,'',location.pathname+location.search); } catch (_) {}
      }
      function openMenu(trigger) {
        if (isOpen) { closeButton.focus({preventScroll:true}); return; }
        opener=trigger || document.activeElement;
        isOpen=true;
        error.hidden=true;
        root.hidden=false;
        panel.scrollTop=0;
        lockPage();
        updateTriggers();
        closeButton.focus({preventScroll:true});
      }
      function closeMenu(restoreFocus) {
        if (!isOpen) return;
        isOpen=false;
        root.hidden=true;
        unlockPage();
        updateTriggers();
        clearMenuHash();
        if (restoreFocus && opener && opener.isConnected && typeof opener.focus==='function') opener.focus({preventScroll:true});
      }
      function focusable() {
        return Array.from(panel.querySelectorAll('a[href],button,input,select,textarea,[tabindex]')).filter(function (node) {
          return !node.disabled && node.tabIndex>=0 && node.getClientRects().length && !node.closest('[inert]');
        });
      }
      document.addEventListener('click',function (event) {
        if (event.defaultPrevented || event.button!==0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        var trigger=findTrigger(event.target);
        if (!trigger) return;
        event.preventDefault();
        event.stopPropagation();
        openMenu(trigger);
      },true);
      document.addEventListener('keydown',function (event) {
        if (!isOpen) {
          var trigger=findTrigger(event.target);
          if (trigger && !['A','BUTTON','INPUT'].includes(trigger.tagName) && ['Enter',' '].includes(event.key)) {
            event.preventDefault();
            openMenu(trigger);
          }
          return;
        }
        if (event.key==='Escape') {
          event.preventDefault();
          event.stopPropagation();
          closeMenu(true);
        } else if (event.key==='Tab') {
          var nodes=focusable(),first=nodes[0],last=nodes[nodes.length-1];
          if (!nodes.length) { event.preventDefault(); panel.focus(); }
          else if (event.shiftKey && document.activeElement===first) { event.preventDefault(); last.focus(); }
          else if (!event.shiftKey && document.activeElement===last) { event.preventDefault(); first.focus(); }
        }
      },true);
      document.addEventListener('focusin',function (event) { if (isOpen && !panel.contains(event.target)) closeButton.focus({preventScroll:true}); });
      closeButton.addEventListener('click',function () { closeMenu(true); });
      root.addEventListener('click',function (event) { if (event.target===root) closeMenu(true); });
      panel.addEventListener('click',function (event) {
        var link=event.target.closest('a[href]');
        if (link) closeMenu(true);
        // Native link behavior is preserved, including #popup:... in Tilda.
      });
      form.addEventListener('submit',function (event) {
        event.preventDefault();
        var query=input.value.trim(),url;
        try {
          url=new URL(CONFIG.searchUrl,document.baseURI);
          if (!/^https?:$/.test(url.protocol)) throw Error('Invalid search URL');
          if (query) url.searchParams.set(CONFIG.searchParam,query);
          else url.searchParams.delete(CONFIG.searchParam);
        } catch (_) {
          error.textContent='Не удалось открыть поиск. Попробуйте позже.';
          error.hidden=false;
          return;
        }
        // Optional integration: a catalog script can prevent this event and handle filtering itself.
        var searchEvent=new CustomEvent('valmo:menu-search',{bubbles:true,cancelable:true,detail:{query:query,url:url.href}});
        var navigate=panel.dispatchEvent(searchEvent);
        closeMenu(false);
        if (navigate) window.location.assign(url.href);
      });
      window.addEventListener('hashchange',function () { if (location.hash==='#menuopen') openMenu(null); else if (isOpen) closeMenu(false); });
      window.addEventListener('pagehide',function () { closeMenu(false); });
      root.vmm={open:openMenu,close:function(){closeMenu(true);}};
      updateTriggers();
      if (location.hash==='#menuopen') openMenu(null);
    });
  }
  if (document.body) mount();
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',mount,{once:true});
})();
