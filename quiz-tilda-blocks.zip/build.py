from pathlib import Path
root = Path(__file__).resolve().parent
code = (root / 'quiz-blocks.js').read_text()
config = '''// Можно оставить пустыми: скрипт ищет заголовки вопросов и одну форму с телефоном.
// Если нужны точные ID: questionBlocks: ['#rec111', '#rec222', '#rec333'],
// contact: '#rec444, #rec445', thanks: '#rec555', form: '#rec445 form'.
window.AvdeevaBlocksQuizConfig = {
  questionBlocks: ['', '', ''],
  contact: '.uc-quiz-contact',
  thanks: '.uc-quiz-thanks',
  form: '',
  scrollOffset: 80
};'''
(root / 'tilda-quiz-fix.html').write_text('<!-- Вставить в T123 после существующих блоков. Прежний JS квиза удалить. -->\n<script>\n' + config + '\n' + code + '\n</script>\n')
print('Built', (root / 'tilda-quiz-fix.html').stat().st_size, 'bytes')
