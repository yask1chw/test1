(function(){
 'use strict';
 var CONFIG={recordId:'rec6201254901',quotePopup:'#popup:valmo-kp',addHeading:true,homeUrl:'/',applyMenuQuery:true};

 // Place this T123 BEFORE the native catalog block so its first initialization sees the search flag.
 (function enableNativeSearch(){
  var key='__valmoCatalogSearchHook';if(window[key])return;
  var state=window[key]={installed:false,initialized:false};
  function wrap(){
   if(typeof window.t_catalog_init!=='function')return false;
   if(window.t_catalog_init.vcsWrapped){state.installed=true;return true;}
   var original=window.t_catalog_init;
   var wrapped=function(recid,options){
    if(String(recid)===CONFIG.recordId.replace(/^rec/,'')){
     options=Object.assign({},options,{hideSearchSort:false,hideSearch:false,useSeparateHideSearchSort:false});state.initialized=true;
    }
    return original.call(this,recid,options);
   };
   wrapped.vcsWrapped=true;window.t_catalog_init=wrapped;state.installed=true;return true;
  }
  if(!wrap()){
   if(typeof window.t_onFuncLoad==='function')window.t_onFuncLoad('t_catalog_init',wrap);
   var tries=0,timer=setInterval(function(){if(wrap()||++tries>600)clearInterval(timer);},50);
  }
 })();
 var PRODUCTS=[{"model":"LiuGong 835H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[{"label":"Объём ковша","value":"1,8 м³"},{"label":"Эксплуатационная масса","value":"10 075 кг"},{"label":"Мощность","value":"85 / 116 кВт / л.с."},{"label":"Высота выгрузки","value":"2 930 мм"}]},{"model":"LiuGong ZL30","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 836","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG835H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 856H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG856","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG870H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG836","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 816С","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG820C","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong ZL50CN","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 842H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 820C","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 855H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG842","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong ZL30G","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG816С","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG886H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 862H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG862H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 8128H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 890H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG8128H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 877H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 886H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG877H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG855H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong CLG890H","brand":"LiuGong","type":"Фронтальный погрузчик","keySpecs":[]},{"model":"LiuGong 933","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 9035e","brand":"LiuGong","type":"Мини-экскаватор","keySpecs":[]},{"model":"LiuGong CLG952EHD","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG933Е","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 9027FZTS","brand":"LiuGong","type":"Мини-экскаватор","keySpecs":[]},{"model":"LiuGong CLG915E","brand":"LiuGong","type":"Экскаватор","keySpecs":[]},{"model":"LiuGong 990FHD","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG9035e","brand":"LiuGong","type":"Мини-экскаватор","keySpecs":[]},{"model":"LiuGong CLG936E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG956EHD","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 952E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG990FHD","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 9125F","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG923FN","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG950Е","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG939E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG920E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 9018F","brand":"LiuGong","type":"Мини-экскаватор","keySpecs":[]},{"model":"LiuGong 923FN","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG925D","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 922E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong W915E","brand":"LiuGong","type":"Колёсный экскаватор","keySpecs":[]},{"model":"LiuGong CLG922E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 906E","brand":"LiuGong","type":"Мини-экскаватор","keySpecs":[]},{"model":"LiuGong CLG925E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 936E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong CLG970Е","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 945E","brand":"LiuGong","type":"Гусеничный экскаватор","keySpecs":[]},{"model":"LiuGong 909ECR","brand":"LiuGong","type":"Мини-экскаватор","keySpecs":[]},{"model":"LiuGong 915E","brand":"LiuGong","type":"Экскаватор","keySpecs":[]},{"model":"SHACMAN SX33186V366","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3256dr384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN X5000 самосвал 8x4","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX32586T385","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258DR384 F2000","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX331864366C","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN X5000 самосвал","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN X3000 8x4","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3318DT366","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN X3000 самосвал","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3315DT366","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3254js384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"Самосвал Shacman F3000","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3256dt385","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN X5000 самосвал 6x4","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3255dr384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX33186T366C","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258dt384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3316dr366","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3256dr385","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3251dr384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258dv385","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX32586T384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX33186T366","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258DR384","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX32488L354C","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"Самосвал SHACMAN L3000","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258dr385","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258DT385","brand":"SHACMAN","type":"Самосвал","keySpecs":[]},{"model":"SHACMAN SX3258DR384 6x4","brand":"SHACMAN","type":"Самосвал","keySpecs":[]}];
 var normalize=function(s){return String(s||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLowerCase();};
 var index=new Map(PRODUCTS.map(function(p){return [normalize(p.model),p];}));
 function node(tag,cls,text){var n=document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n;}
 function init(){
  var root=document.getElementById(CONFIG.recordId);if(!root)return false;if(root.vcs)return true;
  var frame=0,brandApplied=false,queryApplied=false;
  function schedule(){if(!frame)frame=requestAnimationFrame(function(){frame=0;refresh();});}
  if(CONFIG.addHeading&&!root.querySelector('.vcs-heading')){
   var header=node('header','vcs-heading'),crumb=node('p','vcs-breadcrumb'),home=node('a','', 'Главная');home.href=CONFIG.homeUrl;crumb.append(home,document.createTextNode(' / Каталог техники'));
   header.append(crumb,node('h1','','Выберите технику под ваши задачи'),node('p','vcs-intro','Подберём технику, рассчитаем лизинг и организуем поставку по всей России.'));root.prepend(header);
  }
  function decorate(card){
   var title=card.querySelector('.js-product-name');if(!title)return;
   var model=title.textContent.trim(),key=(card.dataset.productUid||'')+'|'+model;
   if(card.dataset.vcsKey!==key){card.querySelectorAll('[data-vcs-owned]').forEach(function(n){n.remove();});card.classList.remove('vcs-has-meta');}
   var p=index.get(normalize(model)),text=card.querySelector('.t-catalog__card__textwrapper'),buttons=card.querySelector('.t-catalog__card__price-buttons');
   if(p&&text&&!text.querySelector('.vcs-meta')){
    var meta=node('p','vcs-meta',p.brand+' · '+p.type);meta.dataset.vcsOwned='1';text.prepend(meta);card.classList.add('vcs-has-meta');
    if(p.keySpecs&&p.keySpecs.length){var list=node('ul','vcs-specs');list.dataset.vcsOwned='1';p.keySpecs.slice(0,4).forEach(function(s){var li=node('li');li.append(node('span','',s.label),node('strong','',s.value));list.append(li);});text.append(list);}
   }
   if(buttons){var existing=buttons.querySelector('.vcs-actions'),nativeButtons=Array.from(buttons.querySelectorAll('a,button')).some(function(n){return !n.closest('.vcs-actions');});if(nativeButtons&&existing)existing.remove();}
   if(buttons&&!buttons.querySelector('a,button')){
    var actions=node('div','vcs-actions'),detail=node('a','vcs-detail','Подробнее'),quote=node('a','vcs-quote','Узнать цену');actions.dataset.vcsOwned='1';
    detail.href=card.dataset.productUrl||'#';quote.href=CONFIG.quotePopup;quote.dataset.vcsProduct=model;
    detail.setAttribute('aria-label','Подробнее — '+model);quote.setAttribute('aria-label','Узнать цену — '+model);actions.append(detail,quote);buttons.append(actions);
   }
   card.dataset.vcsKey=key;
  }
  function filters(){
   var sidebar=root.querySelector('.t-catalog__sidebar');if(!sidebar)return;
   sidebar.querySelectorAll('.js-catalog-filter-mob-btn').forEach(function(b){b.setAttribute('role','button');b.tabIndex=0;b.setAttribute('aria-expanded',String(root.classList.contains('vcs-mobile-open')));});
   if(!sidebar.querySelector('.vcs-filter-heading'))sidebar.prepend(node('h2','vcs-filter-heading','Фильтр'));
   var groups=sidebar.querySelectorAll('.js-catalog-filter-item');
   var nativeSearch=root.querySelector('input[type="search"],input.js-catalog-filter-search,input[name="search"]');
   if(nativeSearch){nativeSearch.placeholder='Модель, бренд или тип';nativeSearch.setAttribute('aria-label','Поиск по каталогу Тильды');}

   groups.forEach(function(g){var field=g.querySelector('.js-catalog-filter-opt'),label=g.querySelector('.js-catalog-filter-item-title'),name=normalize(label&&label.textContent);
    var cls=field&&field.name==='brand'?'vcs-filter-brand':name==='наличие'?'vcs-filter-availability':name==='тип техники'?'vcs-filter-type':'';
    if(cls&&!g.classList.contains(cls))g.classList.add(cls);
    if(cls==='vcs-filter-type')typeSelect(g);

    var val=field&&field.value;
    g.querySelectorAll('.js-catalog-filter-custom-select').forEach(function(option){var active=Boolean(val)&&val===option.dataset.selectVal;if(option.classList.contains('vcs-is-active')!==active)option.classList.toggle('vcs-is-active',active);});
   });
   var brand=sidebar.querySelector('.vcs-filter-brand');
   if(brand){var names=Array.from(brand.querySelectorAll('[data-select-val]')).map(function(n){return normalize(n.dataset.selectVal);}),parts=Array.from(sidebar.querySelectorAll('.t-catalog__parts-item-title')).map(function(n){return normalize(n.textContent);}).filter(function(n){return n!=='все';});
    var current=sidebar.querySelector('.t-catalog__parts-current[data-storepart-uid]');var hide=Boolean(parts.length)&&parts.every(function(p){return names.indexOf(p)!==-1;})&&(!current||!current.dataset.storepartUid);if(sidebar.classList.contains('vcs-brands-only')!==hide)sidebar.classList.toggle('vcs-brands-only',hide);
   }
   if(!sidebar.querySelector('.vcs-reset')&&root.querySelector('.js-catalog-filter-reset')){var reset=node('button','vcs-reset','↻ Сбросить фильтры');reset.type='button';sidebar.append(reset);}
  }
  function typeSelect(group){
   var boxes=Array.from(group.querySelectorAll('input.js-catalog-filter-opt-chb'));if(!boxes.length)return;
   var select=group.querySelector('select.vcs-type-select');
   if(!select){
    select=node('select','vcs-type-select');select.dataset.vcsOwner=CONFIG.recordId;select.setAttribute('aria-label','Тип техники');
    var wrap=group.querySelector('.js-catalog-filter-item-controls-wr');
    if(wrap){wrap.classList.add('vcs-native-types');wrap.setAttribute('aria-hidden','true');group.insertBefore(select,wrap);}else group.append(select);
   }
   var signature=JSON.stringify(boxes.map(function(box){return [box.dataset.filterValue||box.name,box.disabled];}));
   if(select.dataset.vcsOptions!==signature){
    select.replaceChildren();var all=node('option','','Все типы');all.value='';select.append(all);
    boxes.forEach(function(box){var option=node('option','',box.dataset.filterValue||box.name);option.value=box.dataset.filterValue||box.name;option.disabled=box.disabled;select.append(option);box.tabIndex=-1;});select.dataset.vcsOptions=signature;
   }
   var checked=boxes.filter(function(box){return box.checked;});
   var multiple=select.querySelector('[data-vcs-multiple]');
   if(checked.length>1){if(!multiple){multiple=node('option','','Выбрано типов: '+checked.length);multiple.value='__multiple__';multiple.disabled=true;multiple.dataset.vcsMultiple='1';select.append(multiple);}select.value='__multiple__';}
   else{if(multiple)multiple.remove();select.value=checked.length?(checked[0].dataset.filterValue||checked[0].name):'';}
  }
  function applyQuery(){
   if(!CONFIG.applyMenuQuery)return;
   var params=new URLSearchParams(location.search),brand=params.get('brand'),q=params.get('q');
   if(brand&&!brandApplied){var group=root.querySelector('.vcs-filter-brand'),match=group&&Array.from(group.querySelectorAll('[data-select-val]')).find(function(n){return normalize(n.dataset.selectVal)===normalize(brand);});if(match){brandApplied=true;match.click();}}
   if(q&&!queryApplied){var input=root.querySelector('input[type="search"],input.js-catalog-filter-search,input[name="search"]');if(input){queryApplied=true;input.value=q;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',bubbles:true}));}}
  }
  function refresh(){filters();root.querySelectorAll('.js-catalog-grid-cont .t-catalog__card').forEach(decorate);applyQuery();}
  root.addEventListener('click',function(e){
   var button=e.target.closest('.js-catalog-filter-mob-btn');
   if(button&&window.matchMedia('(max-width:1023px)').matches){
    e.preventDefault();e.stopImmediatePropagation();var open=!root.classList.contains('vcs-mobile-open');root.classList.toggle('vcs-mobile-open',open);button.setAttribute('aria-expanded',String(open));
   }
  },true);
  root.addEventListener('keydown',function(e){var button=e.target.closest('.js-catalog-filter-mob-btn');if(button&&['Enter',' '].includes(e.key)){e.preventDefault();button.click();}});
  document.addEventListener('change',function(e){
   var select=e.target.closest('select.vcs-type-select');if(!select||select.dataset.vcsOwner!==CONFIG.recordId)return;
   var group=select.closest('.js-catalog-filter-item');if(!group)return;
   var value=select.value,boxes=Array.from(group.querySelectorAll('input.js-catalog-filter-opt-chb'));
   boxes.filter(function(box){return box.checked&&(box.dataset.filterValue||box.name)!==value;}).forEach(function(box){box.click();});
   var next=boxes.find(function(box){return (box.dataset.filterValue||box.name)===value;});if(next&&!next.checked)next.click();schedule();
  });
  root.addEventListener('click',function(e){
   var detail=e.target.closest('.vcs-detail');if(detail){e.preventDefault();var card=detail.closest('.t-catalog__card'),original=card.querySelector('.t-catalog__card__textwrapper .js-product-link')||card.querySelector('.js-product-link');if(original)original.click();else location.assign(detail.href);return;}
   var reset=e.target.closest('.vcs-reset');if(reset){var nativeReset=root.querySelector('.js-catalog-filter-reset');if(nativeReset)nativeReset.click();schedule();return;}
   var quote=e.target.closest('.vcs-quote');if(quote)root.dispatchEvent(new CustomEvent('valmo:catalog-quote',{bubbles:true,detail:{title:quote.dataset.vcsProduct,uid:quote.closest('.t-catalog__card').dataset.productUid}}));
   schedule();
  });
  root.addEventListener('change',schedule);window.addEventListener('hashchange',schedule);
  var observer=new MutationObserver(schedule);observer.observe(root,{subtree:true,childList:true});
  root.vcs={refresh:refresh};refresh();return true;
 }
 if(!init()){var waiting=new MutationObserver(function(){if(init())waiting.disconnect();});waiting.observe(document.documentElement,{childList:true,subtree:true});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
})();
