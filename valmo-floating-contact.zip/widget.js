(function () {
  'use strict';
  // Replace callbackPopup with the anchor of your native Tilda popup.
  var CONFIG = {
    telegramUrl: 'https://t.me/ValmoRus_Spectehnika',
    callbackPopup: '#popup:valmo-callback',
    right: 20,
    bottom: 20,
    mobileRight: 16,
    mobileBottom: 20
  };
  function init() {
    var roots = Array.from(document.querySelectorAll('[data-valmo-floating]'));
    var existing = roots.find(function (r) { return r.dataset.vfcReady === 'true'; });
    roots.forEach(function (root) {
      if (root.dataset.vfcReady === 'true') return;
      // One floating menu per page, including when HTML blocks are duplicated.
      if (existing) { root.remove(); return; }
      existing = root;
      root.dataset.vfcReady = 'true';
      // A transformed/clipped Zero Block must not become the fixed-position container.
      document.body.appendChild(root);
      root.style.setProperty('--vfc-right', CONFIG.right + 'px');
      root.style.setProperty('--vfc-bottom', CONFIG.bottom + 'px');
      root.style.setProperty('--vfc-mobile-right', CONFIG.mobileRight + 'px');
      root.style.setProperty('--vfc-mobile-bottom', CONFIG.mobileBottom + 'px');
      var toggle = root.querySelector('[data-vfc-toggle]');
      var menu = root.querySelector('[data-vfc-menu]');
      var headset = root.querySelector('[data-vfc-headset]');
      var cross = root.querySelector('[data-vfc-cross]');
      var telegram = root.querySelector('[data-vfc-telegram]');
      var callback = root.querySelector('[data-vfc-callback]');
      var id = 'vfc-menu-' + Math.random().toString(36).slice(2,10);
      menu.id = id;
      toggle.setAttribute('aria-controls', id);
      telegram.setAttribute('href', CONFIG.telegramUrl);
      callback.setAttribute('href', CONFIG.callbackPopup);
      var open = false;
      function setOpen(next, restoreFocus) {
        open = Boolean(next);
        menu.hidden = !open;
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Закрыть меню связи' : 'Связаться с нами');
        headset.hidden = open;
        cross.hidden = !open;
        if (restoreFocus) toggle.focus({ preventScroll:true });
      }
      toggle.addEventListener('click', function () { setOpen(!open, false); });
      toggle.addEventListener('keydown', function (event) {
        if (event.key !== 'ArrowUp' && event.key !== 'ArrowDown') return;
        event.preventDefault();
        setOpen(true, false);
        (event.key === 'ArrowUp' ? callback : telegram).focus();
      });
      root.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && open) {
          event.preventDefault();
          event.stopPropagation();
          setOpen(false, true);
        }
      });
      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && open) setOpen(false, root.contains(document.activeElement));
      });
      document.addEventListener('click', function (event) {
        if (open && !root.contains(event.target)) setOpen(false, false);
      });
      root.addEventListener('focusout', function (event) {
        if (open && event.relatedTarget && !root.contains(event.relatedTarget)) setOpen(false, false);
      });
      [telegram, callback].forEach(function (link) {
        link.addEventListener('click', function () {
          setOpen(false, true);
          // Native links are preserved: Tilda handles #popup:..., Telegram opens a new tab.
          // No preventDefault, manual popup simulation, or form submission here.
        });
      });
      setOpen(false, false);
      root.vfc = { open:function(){ setOpen(true,false); }, close:function(){ setOpen(false,false); } };
    });
  }
  if (document.body) init();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once:true });
})();
