(function () {
  "use strict";

  // НАСТРОЙКИ. Исходная кнопка «Получить цену» и её #order не меняются.
  var CONFIG = {
    recordId: "6201254901",
    catalogPath: "/catalog",
    contactPopup: "#popup:valmo-kp",
    relatedTitle: "Похожие модели",
    stickyAction: true,
  };

  if (window.__valmoProductPopupStyle) return;
  window.__valmoProductPopupStyle = true;
  var states = new Map();
  var frame = 0;
  var uid = 0;
  var NON_TECHNICAL = ["где применяется", "комплектации", "срок поставки"];

  function norm(value) {
    return String(value || "")
      .normalize("NFKC")
      .replace(/ё/g, "е")
      .trim()
      .replace(/\s+/g, " ")
      .toLowerCase();
  }
  function text(element) {
    return element ? element.textContent.trim() : "";
  }
  function element(tag, className, content) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (content) node.textContent = content;
    return node;
  }
  function owned(node) {
    node.dataset.vppOwned = "true";
    return node;
  }
  function pair(value) {
    var i = value.indexOf(":");
    return i < 1
      ? null
      : { label: value.slice(0, i).trim(), value: value.slice(i + 1).trim() };
  }
  function nativePairs(chars) {
    return chars
      ? Array.from(chars.querySelectorAll(".js-catalog-prod-charcs"))
          .map(function (row) {
            return pair(text(row));
          })
          .filter(Boolean)
      : [];
  }
  function sections(full) {
    if (!full) return [];
    return Array.from(full.children)
      .filter(function (heading) {
        return (
          /^H[23]$/.test(heading.tagName) &&
          heading.nextElementSibling &&
          heading.nextElementSibling.tagName === "UL" &&
          NON_TECHNICAL.indexOf(norm(text(heading))) === -1
        );
      })
      .map(function (heading) {
        return {
          title: text(heading),
          rows: Array.from(heading.nextElementSibling.children)
            .map(function (li) {
              return pair(text(li));
            })
            .filter(Boolean),
        };
      })
      .filter(function (group) {
        return group.rows.length;
      });
  }
  function belongs(popup, product) {
    if (popup.querySelector('[data-catalog-recid="' + CONFIG.recordId + '"]'))
      return true;
    if (
      popup.querySelector('[aria-controls="carousel_' + CONFIG.recordId + '"]')
    )
      return true;
    try {
      return (
        new URL(product.dataset.productUrl, location.href).pathname.indexOf(
          CONFIG.catalogPath.replace(/\/$/, "") + "/tproduct/",
        ) === 0
      );
    } catch (_) {
      return false;
    }
  }
  function schedule() {
    if (frame) return;
    frame = requestAnimationFrame(function () {
      frame = 0;
      refresh();
    });
  }
  function requestNativeResize(state) {
    if (state.resizePending) return;
    state.resizePending = true;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        state.resizePending = false;
        if (
          state.product.isConnected &&
          state.gallery.getBoundingClientRect().width > 0
        )
          window.dispatchEvent(new Event("resize"));
      });
    });
  }
  function createState(popup, product, gallery, info) {
    var state = {
      popup: popup,
      product: product,
      gallery: gallery,
      info: info,
      signature: null,
      lastWidth: 0,
      resizePending: false,
    };
    states.set(product, state);
    popup.classList.add("vpp-popup");
    popup.dataset.vppRecord = CONFIG.recordId;
    var nativeClose = popup.querySelector(".t-popup__close-wrapper");
    if (nativeClose) {
      nativeClose.setAttribute("role", "button");
      nativeClose.tabIndex = 0;
      nativeClose.setAttribute("aria-label", "Закрыть товар");
    }

    product.classList.add("vpp-product");
    gallery.parentElement.classList.add("vpp-hero");
    state.observer = new ResizeObserver(function () {
      var width = Math.round(gallery.getBoundingClientRect().width);
      if (width > 0 && width !== state.lastWidth) {
        state.lastWidth = width;
        requestNativeResize(state);
      }
    });
    state.observer.observe(gallery);
    state.onScroll = function () {
      var container = popup.querySelector(".t-popup__container");
      var top = Math.max(
        popup.scrollTop || 0,
        container ? container.scrollTop : 0,
      );
      var show = CONFIG.stickyAction && top > 640;
      if (popup.classList.contains("vpp-scrolled") !== show)
        popup.classList.toggle("vpp-scrolled", show);
    };
    popup.addEventListener("scroll", state.onScroll, {
      capture: true,
      passive: true,
    });
    return state;
  }
  function addSummary(state, title, rows, groups, hasPrice) {
    var info = state.info;
    info.querySelectorAll("[data-vpp-owned]").forEach(function (node) {
      node.remove();
    });
    function get(name) {
      var row = rows.find(function (row) {
        return norm(row.label) === norm(name);
      });
      return row ? row.value : "";
    }
    var type = get("Тип техники");
    info.prepend(
      owned(
        element("p", "vpp-eyebrow", type ? "VALMO / " + type : "VALMO RUS"),
      ),
    );
    var summary = owned(element("div", "vpp-summary"));
    var status = get("Наличие");
    var year = get("Год выпуска");
    if (status || year) {
      var statusRow = element("div", "vpp-status-row");
      if (status) statusRow.append(element("span", "vpp-status", status));
      if (year)
        statusRow.append(element("span", "vpp-year", "Год выпуска: " + year));
      summary.append(statusRow);
    }
    var keys = groups.find(function (g) {
      return norm(g.title) === "основные характеристики";
    });
    if (keys) {
      var list = element("ul", "vpp-key-specs");
      keys.rows.slice(0, 3).forEach(function (row) {
        var li = element("li");
        li.append(
          element("strong", "", row.value),
          element("span", "", row.label),
        );
        list.append(li);
      });
      summary.append(list);
    }
    var facts = element("div", "vpp-facts");
    ["Гарантия", "Сборка"].forEach(function (key) {
      var value = get(key);
      if (value) facts.append(element("p", "", key + ": " + value));
    });
    if (facts.children.length) summary.append(facts);
    var priceWrapper = info.querySelector(
      ".t-catalog__prod-popup__price-wrapper",
    );
    if (priceWrapper) priceWrapper.before(summary);
    else
      info
        .querySelector(".t-catalog__prod-popup__title-wrapper")
        .after(summary);
    if (!hasPrice) {
      var fallback = owned(
        element("p", "vpp-price-request", "Цена по запросу"),
      );
      if (priceWrapper) priceWrapper.after(fallback);
      else summary.after(fallback);
    }
    var buttons = info.querySelector(".t-catalog__prod-popup__btn-wrapper");
    if (buttons) {
      var leasing = owned(element("a", "vpp-secondary", "Рассчитать лизинг"));
      leasing.href = CONFIG.contactPopup;
      leasing.dataset.vppTopic = "Рассчитать лизинг";
      buttons.after(leasing);
      var inspection = owned(
        element(
          "a",
          "vpp-inspection",
          "Записаться на осмотр техники на площадке",
        ),
      );
      inspection.href = CONFIG.contactPopup;
      inspection.dataset.vppTopic = "Записаться на осмотр";
      leasing.after(inspection);
    }
  }
  function tableGroup(group) {
    var section = element("section", "vpp-spec-group");
    section.append(element("h3", "", group.title));
    var wrap = element("div", "vpp-table-wrap"),
      table = element("table", "vpp-spec-table"),
      body = element("tbody");
    group.rows.forEach(function (row) {
      var tr = element("tr"),
        th = element("th", "", row.label);
      th.scope = "row";
      tr.append(th, element("td", "", row.value));
      body.append(tr);
    });
    table.append(body);
    wrap.append(table);
    section.append(wrap);
    return section;
  }
  function selectTab(details, tab, focus) {
    details.querySelectorAll("[data-vpp-tab]").forEach(function (button) {
      var selected = button.dataset.vppTab === tab;
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
      if (selected && focus) button.focus({ preventScroll: true });
    });
    details.querySelectorAll("[data-vpp-panel]").forEach(function (panel) {
      panel.hidden = panel.dataset.vppPanel !== tab;
    });
  }
  function addDetails(state, title, full, rows, groups) {
    state.product
      .querySelectorAll(":scope > .vpp-details")
      .forEach(function (node) {
        node.remove();
      });
    var details = owned(element("section", "vpp-details"));
    var layout = element("div", "vpp-details-grid"),
      main = element("div", "vpp-details-main");
    var tabs = element("div", "vpp-tabs");
    tabs.setAttribute("role", "tablist");
    tabs.setAttribute("aria-label", "Информация о товаре");
    var id = "vpp-" + ++uid;
    var description = full
      ? full.cloneNode(true)
      : element("div", "", "Описание уточняйте у менеджера.");
    description.className = "vpp-description";
    description.removeAttribute("id");
    description.querySelectorAll("[id]").forEach(function (node) {
      node.removeAttribute("id");
    });
    description.querySelectorAll("*").forEach(function (node) {
      Array.from(node.classList)
        .filter(function (c) {
          return c.indexOf("js-") === 0;
        })
        .forEach(function (c) {
          node.classList.remove(c);
        });
    });
    description.querySelectorAll("script").forEach(function (node) {
      node.remove();
    });
    Array.from(description.children)
      .filter(function (heading) {
        return (
          /^H[23]$/.test(heading.tagName) &&
          heading.nextElementSibling &&
          heading.nextElementSibling.tagName === "UL" &&
          NON_TECHNICAL.indexOf(norm(text(heading))) === -1
        );
      })
      .forEach(function (heading) {
        heading.nextElementSibling.remove();
        heading.remove();
      });
    var specs = element("div", "vpp-specifications");
    var covered = [];
    groups.forEach(function (g) {
      specs.append(tableGroup(g));
      g.rows.forEach(function (row) {
        covered.push({
          label: norm(row.label),
          full: norm(g.title + " — " + row.label),
          value: norm(row.value),
        });
      });
    });
    var extra = rows.filter(function (row) {
      return !covered.some(function (source) {
        var key = norm(row.label);
        return (
          norm(row.value) === source.value &&
          (key === source.label ||
            key === source.full ||
            source.full.indexOf(key) === 0)
        );
      });
    });
    if (extra.length)
      specs.append(
        tableGroup({
          title: groups.length
            ? "Дополнительные характеристики"
            : "Характеристики",
          rows: extra,
        }),
      );
    var panels = [{ key: "description", label: "Описание", node: description }];
    if (specs.children.length)
      panels.push({
        key: "specifications",
        label: "Технические характеристики",
        node: specs,
      });
    panels.forEach(function (item) {
      var button = element("button", "", item.label);
      button.type = "button";
      button.dataset.vppTab = item.key;
      button.id = id + "-" + item.key + "-tab";
      button.setAttribute("role", "tab");
      button.setAttribute("aria-controls", id + "-" + item.key);
      item.node.id = id + "-" + item.key;
      item.node.dataset.vppPanel = item.key;
      item.node.setAttribute("role", "tabpanel");
      item.node.setAttribute("aria-labelledby", button.id);
      tabs.append(button);
    });
    main.append(tabs);
    panels.forEach(function (item) {
      main.append(item.node);
    });
    var help = element("aside", "vpp-help");
    help.append(
      element("h3", "", title + " — наличие и поставка"),
      element(
        "p",
        "",
        "Оставьте заявку — менеджер уточнит наличие, комплектацию и сроки поставки.",
      ),
    );
    var request = element("a", "", "Узнать наличие");
    request.href = CONFIG.contactPopup;
    request.dataset.vppTopic = "Узнать наличие";
    var category = state.popup.querySelector(
      '[data-breadcrumb-role="category"]',
    );
    var back = element(
      "a",
      "vpp-back",
      category ? "Назад в категорию" : "Назад в каталог",
    );
    back.dataset.vppAction = "back-catalog";
    back.href = CONFIG.catalogPath;
    help.append(request, back);
    layout.append(main, help);
    details.append(layout);
    state.product.append(details);
    selectTab(details, "description", false);
  }
  function originalAction(product) {
    return product.querySelector(
      ".t-catalog__prod-popup__btn-wrapper a:not([data-vpp-owned])",
    );
  }
  function addSticky(state, title) {
    state.popup
      .querySelectorAll(":scope > .vpp-sticky")
      .forEach(function (node) {
        node.remove();
      });
    if (!CONFIG.stickyAction || !originalAction(state.product)) return;
    var bar = owned(element("div", "vpp-sticky"));
    bar.append(element("strong", "", title));
    var sourceAction = originalAction(state.product);
    var label = sourceAction && sourceAction.querySelector(".t-btnflex__text");
    var button = element("button", "", text(label) || "Получить цену");
    button.type = "button";
    button.dataset.vppAction = "native-price";
    bar.append(button);
    state.popup.append(bar);
  }
  function refresh() {
    states.forEach(function (state, product) {
      if (!product.isConnected) {
        state.observer.disconnect();
        state.popup.removeEventListener("scroll", state.onScroll, true);
        states.delete(product);
      }
    });
    document.querySelectorAll(".t-popup").forEach(function (popup) {
      var product = popup.querySelector(".js-catalog-product");
      if (!product || !belongs(popup, product)) return;
      var gallery = product.querySelector(".js-catalog-prod-slider"),
        info = product.querySelector(".t-catalog__prod-popup__info");
      if (!gallery || !info) return;
      var state =
        states.get(product) || createState(popup, product, gallery, info);
      var name = info.querySelector(".t-catalog__prod-popup__name");
      var nativeText = info.querySelector(".js-catalog-prod-text");
      var full =
        nativeText && nativeText.querySelector(".js-catalog-prod-all-text");
      var chars =
        nativeText && nativeText.querySelector(".js-catalog-prod-all-charcs");
      var price = info.querySelector(
        ".t-catalog__prod-popup__price-value.js-product-price",
      );
      var signature = [
        product.dataset.productUid,
        text(name),
        text(full),
        text(chars),
        text(price),
      ].join("\u0001");
      if (signature === state.signature) return;
      state.signature = signature;
      if (name) {
        name.setAttribute("role", "heading");
        name.setAttribute("aria-level", "1");
      }
      if (nativeText) nativeText.classList.add("vpp-native-text");
      var rows = nativePairs(chars),
        groups = sections(full),
        title = text(name);
      addSummary(state, title, rows, groups, Boolean(text(price)));
      addDetails(state, title, full, rows, groups);
      addSticky(state, title);
      var related = popup.querySelector(".t-catalog__relevants__title");
      if (
        CONFIG.relatedTitle &&
        related &&
        text(related) !== CONFIG.relatedTitle
      )
        related.textContent = CONFIG.relatedTitle;
      state.onScroll();
      requestNativeResize(state);
    });
  }

  document.addEventListener("click", function (event) {
    var popup = event.target.closest(".vpp-popup");
    if (!popup) return;
    var tab = event.target.closest("[data-vpp-tab]");
    if (tab) {
      selectTab(tab.closest(".vpp-details"), tab.dataset.vppTab, false);
      return;
    }
    var sticky = event.target.closest('[data-vpp-action="native-price"]');
    if (sticky) {
      var product = popup.querySelector(".js-catalog-product"),
        original = originalAction(product);
      if (original) original.click();
      return;
    }
    var back = event.target.closest('[data-vpp-action="back-catalog"]');
    if (back) {
      var nativeBack =
        popup.querySelector('[data-breadcrumb-role="category"]') ||
        popup.querySelector('[data-breadcrumb-role="catalog"]');
      if (nativeBack) {
        event.preventDefault();
        nativeBack.click();
      }
      return;
    }
    var topic = event.target.closest("[data-vpp-topic]");
    if (topic)
      popup.dispatchEvent(
        new CustomEvent("valmo:product-contact", {
          bubbles: true,
          detail: {
            title: text(popup.querySelector(".t-catalog__prod-popup__name")),
            uid: popup.querySelector(".js-catalog-product").dataset.productUid,
            topic: topic.dataset.vppTopic,
          },
        }),
      );
  });
  document.addEventListener(
    "keydown",
    function (event) {
      var close = event.target.closest(".vpp-popup .t-popup__close-wrapper");
      if (close && ["Enter", " "].indexOf(event.key) !== -1) {
        event.preventDefault();
        event.stopPropagation();
        close.click();
        return;
      }

      var tab = event.target.closest(".vpp-popup [data-vpp-tab]");
      if (
        !tab ||
        ["ArrowLeft", "ArrowRight", "Home", "End"].indexOf(event.key) === -1
      )
        return;
      event.preventDefault();
      event.stopPropagation();
      var details = tab.closest(".vpp-details"),
        buttons = Array.from(details.querySelectorAll("[data-vpp-tab]")),
        i = buttons.indexOf(tab);
      i =
        event.key === "Home"
          ? 0
          : event.key === "End"
            ? buttons.length - 1
            : (i + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) %
              buttons.length;
      selectTab(details, buttons[i].dataset.vppTab, true);
    },
    true,
  );
  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["data-product-uid"],
  });
  refresh();
})();
