"""Download the original source photographs on a computer with access to valmo-rus.ru.
Standard Python 3 only; no credentials, no form submissions, no third-party proxy.
"""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlsplit, quote, urlunsplit
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, sys

root=Path(__file__).resolve().parent
assets=json.loads((root/'assets.json').read_text())
out=root/'downloaded-photos';out.mkdir(exist_ok=True)
def download(asset):
 url=urlsplit(asset['url']);safe=urlunsplit((url.scheme,url.netloc,quote(url.path,safe='/%:@'),url.query,''))
 suffix=Path(url.path).suffix.lower() or '.img';path=out/(asset['id']+suffix)
 if path.exists() and path.stat().st_size:return asset['id'],'cached'
 with urlopen(Request(safe,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as response:
  mime=response.headers.get('Content-Type','')
  if 'image/' not in mime and 'svg' not in mime:raise ValueError('Not an image: '+mime)
  data=response.read(25*1024*1024+1)
  if not data or len(data)>25*1024*1024:raise ValueError('Image size invalid')
 path.write_bytes(data);return asset['id'],len(data)
failures=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(download,a):a for a in assets}
 for index,future in enumerate(as_completed(futures),1):
  asset=futures[future]
  try:print(index,'/',len(assets),future.result(),flush=True)
  except Exception as error:failures.append({'id':asset['id'],'url':asset['url'],'error':str(error)});print('ERROR',asset['url'],str(error),flush=True)
(root/'photo-download-report.json').write_text(json.dumps({'images':len(assets),'failures':failures},ensure_ascii=False,indent=2))
print('Folder:',out,'; failed:',len(failures))
sys.exit(1 if failures else 0)
