from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'layout.json').read_text())
def bounds(items):
 x=min(n['x'] for n in items);y=min(n['y'] for n in items);r=max(n['x']+n['w'] for n in items);b=max(n['y']+n['h'] for n in items);return x,y,r-x,b-y
def tree(items,depth=1):
 if len(items)==1:return {'leaf':items[0]}
 x,y,w,h=bounds(items)
 for axis,size in [('y',h),('x',w)]:
  spans=sorted((n[axis],n[axis]+n['h' if axis=='y' else 'w']) for n in items);end=spans[0][1];cuts=[]
  for a,b in spans[1:]:
   if a>end+.5:cuts.append((a-end,(a+end)/2))
   end=max(end,b)
  if cuts and depth<3:
   gap,cut=max(cuts);a=[n for n in items if n[axis]<cut];b=[n for n in items if n[axis]>=cut]
   return {'mode':'VERTICAL' if axis=='y' else 'HORIZONTAL','gap':gap,'children':[tree(a,depth+1),tree(b,depth+1)]}
 # Dense runs become normal vertical flow; decorative backgrounds live on frames.
 return {'mode':'VERTICAL','gap':2,'children':[{'leaf':n} for n in sorted(items,key=lambda n:(round(n['y']/8),n['x']))]}
for s in d['screens']:
 for b in s['blocks']:
  items=[dict(n) for n in b['nodes']];containers=[]
  for bg in sorted([n for n in items if n['type']=='RECT'],key=lambda n:n['w']*n['h']):
   if bg not in items:continue
   inside=[n for n in items if n is not bg and n['x']>=bg['x']-1 and n['y']>=bg['y']-1 and n['x']+n['w']<=bg['x']+bg['w']+2 and n['y']+n['h']<=bg['y']+bg['h']+2]
   if inside and any(n['type']=='TEXT' for n in inside) and bg['h']<=90 and 65<=bg['w']<=500:
    items=[n for n in items if n not in inside and n is not bg];items.append({'type':'BUTTON','name':'button','x':bg['x'],'y':bg['y'],'w':bg['w'],'h':bg['h'],'background':bg,'children':sorted(inside,key=lambda n:n['x'])})
  # Remove broad decorative surfaces from the content flow, retaining them as section paint.
  surfaces=[n for n in items if n['type']=='RECT' and n['w']>=b['width']*.8 and n['h']>=b['height']*.65]
  b['surface']=surfaces[-1] if surfaces else None
  items=[n for n in items if n not in surfaces]
  b['flow']=tree(items) if items else {'mode':'VERTICAL','gap':0,'children':[]}
(P/'layout.json').write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')))
