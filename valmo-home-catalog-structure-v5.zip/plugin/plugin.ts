type NodeColor = {r:number;g:number;b:number;a?:number};
type Item = {type:string;name:string;x:number;y:number;w:number;h:number;fill?:NodeColor;gradient?:{angle:number;stops:{position:number;color:NodeColor}[]};stroke?:NodeColor;strokeWidth?:number;radius?:number;opacity?:number;text?:string;font?:string;weight?:number;fontSize?:number;lineHeight?:number;letterSpacing?:number;color?:NodeColor;href?:string;svg?:string;assetId?:string;fit?:string;position?:string;url?:string};
type Scene = Item & {children?:Scene[];mode?:'HORIZONTAL'|'VERTICAL';abs?:boolean;wrap?:boolean;pad?:number[];gap?:number;rowGap?:number;align?:'MIN'|'CENTER'|'MAX';before?:number;runs?:any[];textAlign?:string;clip?:boolean;borders?:{side:string;width:number;color:NodeColor}[]};
type Block = {name:string;width:number;height:number;y:number;nodes:Item[];scene:Scene;surface?:Item};
type Screen = {route:string;title:string;variant:string;width:number;height:number;blocks:Block[]};
type Asset = {id:string;url:string;white:boolean;name:string};
type ImageReady = {hash:string;width:number;height:number};
const imageCache = new Map<string,ImageReady>();
const fontCache = new Map<string,FontName>();
const iconCache = new Map<string,string>();
const conversion = new Map<string,{resolve:(bytes:Uint8Array)=>void;reject:(e:Error)=>void;timer:number}>();
let cancelled=false, run=false, current:{pages:Map<number,PageNode>;index:Map<number,number>;rowY:Map<number,number>;rowH:Map<number,number>;frames:number;nodes:number}|null=null;
figma.showUI(__html__, {width:520,height:700,themeColors:true});
const post=(message:Record<string,unknown>)=>figma.ui.postMessage(message);
const rgb=(c:NodeColor)=>({r:c.r,g:c.g,b:c.b});
const solid=(c:NodeColor):SolidPaint=>({type:'SOLID',color:rgb(c),opacity:c.a??1});
function waitUI(bytes:Uint8Array,white:boolean):Promise<Uint8Array>{
  const id=Math.random().toString(36).slice(2);
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{conversion.delete(id);reject(Error('Преобразование изображения прервано.'));},45000);conversion.set(id,{resolve,reject,timer});post({type:'convert-image',id,bytes:Array.from(bytes),white});});
}
async function imageFromBytes(bytes:Uint8Array,white:boolean):Promise<ImageReady>{
  const converted=await waitUI(bytes,white);const image=figma.createImage(converted);const size=await image.getSizeAsync();return {hash:image.hash,...size};
}
async function loadAsset(asset:Asset):Promise<ImageReady>{
  const cached=imageCache.get(asset.id);if(cached)return cached;
  let ready:ImageReady;
  if(/\.svg(?:\?|$)/i.test(asset.url)){
    const response=await fetch(asset.url);if(!response.ok)throw Error('HTTP '+response.status);
    const raw=await response.text();if(!/<svg[\s>]/i.test(raw))throw Error('URL не вернул SVG.');
    const node=figma.createNodeFromSvg(raw);node.x=-100000;node.y=-100000;
    try{
      if(asset.white)node.findAll(n=>'fills'in n).forEach(n=>{const shape=n as GeometryMixin;if(Array.isArray(shape.fills)&&shape.fills.length)shape.fills=[{type:'SOLID',color:{r:1,g:1,b:1}}];if(shape.strokes?.length)shape.strokes=[{type:'SOLID',color:{r:1,g:1,b:1}}];});
      const scale=Math.min(3,4096/Math.max(node.width,node.height));
      const bytes=await node.exportAsync({format:'PNG',constraint:{type:'SCALE',value:scale}});const image=figma.createImage(bytes);ready={hash:image.hash,...await image.getSizeAsync()};
    }finally{node.remove();}
  }else{
    try{
      const image=await figma.createImageAsync(asset.url);
      ready=asset.white?await imageFromBytes(await image.getBytesAsync(),true):{hash:image.hash,...await image.getSizeAsync()};
    }catch(_){
      const response=await fetch(asset.url);if(!response.ok)throw Error('HTTP '+response.status);
      ready=await imageFromBytes(new Uint8Array(await response.arrayBuffer()),asset.white);
    }
  }
  imageCache.set(asset.id,ready);return ready;
}
function fontWeight(style:string){const s=style.toLowerCase().replace(/[ -]/g,'');return s.includes('black')?900:s.includes('extrabold')?800:s.includes('semibold')?600:s.includes('bold')?700:s.includes('medium')?500:s.includes('extralight')?200:s.includes('light')?300:s.includes('thin')?100:400;}
async function loadFonts(requests:{family:string;weight:number}[]){
  const all=await figma.listAvailableFontsAsync();const missing:string[]=[];
  for(const request of requests){const key=request.family+':'+request.weight;if(fontCache.has(key))continue;const candidates=all.map(f=>f.fontName).filter(f=>f.family.toLowerCase()===request.family.toLowerCase()&&!/italic/i.test(f.style));
    candidates.sort((a,b)=>Math.abs(fontWeight(a.style)-request.weight)-Math.abs(fontWeight(b.style)-request.weight));
    if(!candidates.length){missing.push(request.family);continue;}
    await figma.loadFontAsync(candidates[0]);fontCache.set(key,candidates[0]);
  }
  if(missing.length)throw Error('Установите шрифты: '+Array.from(new Set(missing)).join(', '));
}
async function preflight(assets:Asset[],fonts:{family:string;weight:number}[]){
  await loadFonts(fonts);const failures:{id:string;url:string;error:string}[]=[];let cursor=0,done=0;
  async function worker(){while(cursor<assets.length&&!cancelled){const asset=assets[cursor++];let timer:number|undefined;try{await Promise.race([loadAsset(asset),new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('Timeout: изображение не загрузилось за 35 секунд.')),35000);})]);}catch(e){failures.push({id:asset.id,url:asset.url,error:String(e)});}finally{if(timer!==undefined)clearTimeout(timer);}done++;post({type:'asset-progress',done,total:assets.length,failed:failures.length});}}
  await Promise.all([worker(),worker(),worker()]);return failures;
}
function gradientPaint(g:NonNullable<Item['gradient']>):GradientPaint{
  const radians=g.angle*Math.PI/180,dx=Math.sin(radians),dy=-Math.cos(radians),sx=.5-dx/2,sy=.5-dy/2;
  return {type:'GRADIENT_LINEAR',gradientStops:g.stops.map(s=>({position:Math.min(1,Math.max(0,s.position)),color:{...rgb(s.color),a:s.color.a??1}})),gradientTransform:[[dx,dy,-dx*sx-dy*sy],[-dy,dx,dy*sx-dx*sy]]};
}
async function makeNode(item:Item,parent:FrameNode){
  let node:SceneNode;
  if(item.type==='TEXT'){
    const text=figma.createText();parent.appendChild(text);
    const font=fontCache.get((item.font||'Manrope')+':'+(item.weight||400));if(!font)throw Error('Шрифт не загружен.');
    text.fontName=font;text.fontSize=item.fontSize||14;text.lineHeight={unit:'PIXELS',value:item.lineHeight||((item.fontSize||14)*1.3)};text.letterSpacing={unit:'PIXELS',value:item.letterSpacing||0};text.characters=item.text||'';text.fills=item.color?[solid(item.color)]:[];text.textAlignVertical='TOP';text.textAutoResize='NONE';text.resize(Math.max(1,item.w),Math.max(1,item.h));node=text;
  }else if(item.type==='SVG'){
    const key=(item.svg||'')+':'+item.w+':'+item.h;let hash=iconCache.get(key);
    if(!hash){const svg=figma.createNodeFromSvg(item.svg||'<svg/>');svg.x=-100000;svg.y=-100000;try{svg.rescale(Math.min(Math.max(1,item.w)/svg.width,Math.max(1,item.h)/svg.height));const bytes=await svg.exportAsync({format:'PNG',constraint:{type:'SCALE',value:2}});hash=figma.createImage(bytes).hash;iconCache.set(key,hash);}finally{svg.remove();}}
    const image=figma.createRectangle();parent.appendChild(image);image.resize(Math.max(1,item.w),Math.max(1,item.h));image.fills=[{type:'IMAGE',imageHash:hash,scaleMode:'FIT'}];image.strokes=[];node=image;
  }else{
    const shape=item.type==='ELLIPSE'?figma.createEllipse():figma.createRectangle();parent.appendChild(shape);shape.resize(Math.max(.1,item.w),Math.max(.1,item.h));
    const fills:Paint[]=[];
    if(item.gradient)fills.push(gradientPaint(item.gradient));if(item.fill)fills.push(solid(item.fill));
    if(item.type==='IMAGE'){
      const image=imageCache.get(item.assetId||'');if(!image)throw Error('Фото не загружено: '+item.assetId);
      fills.push({type:'IMAGE',imageHash:image.hash,scaleMode:item.fit==='FIT'?'FIT':'FILL'});
    }
    shape.fills=fills;
    if(item.stroke&&item.strokeWidth){shape.strokes=[solid(item.stroke)];shape.strokeWeight=item.strokeWidth;shape.strokeAlign='INSIDE';}else shape.strokes=[];
    if('cornerRadius'in shape)shape.cornerRadius=Math.min(item.radius||0,item.w/2,item.h/2);
    node=shape;
  }
  node.name=item.name;if(parent.layoutMode==='NONE'){node.x=item.x;node.y=item.y;}node.opacity=Math.min(1,Math.max(0,item.opacity??1));
  if(item.href)node.setPluginData('sourceHref',item.href);
  if(item.type==='EXTERNAL')node.setPluginData('tildaManualWidget',item.url||'');
  return node;
}
function boxMeta(node:SceneNode,item:Scene){node.setPluginData('sourceBox',JSON.stringify({x:item.x,y:item.y,w:item.w,h:item.h}));}
function gapNode(parent:FrameNode,value:number,vertical:boolean){
  if(value<.05)return;
  const n=figma.createRectangle();parent.appendChild(n);n.name=vertical?'Интервал по вертикали':'Интервал по горизонтали';n.resize(vertical?.01:value,vertical?value:.01);n.fills=[];n.strokes=[];n.layoutGrow=0;n.setPluginData('layoutSpacer','true');
}
async function render(item:Scene,parent:FrameNode|PageNode,origin:{x:number;y:number},root=false):Promise<SceneNode>{
  if(cancelled)throw Error('Импорт остановлен.');
  let node:SceneNode;
  if(item.type==='FRAME'){
    const f=figma.createFrame();parent.appendChild(f);f.name=item.name;f.layoutMode=item.mode||'VERTICAL';f.primaryAxisSizingMode='FIXED';f.counterAxisSizingMode='FIXED';f.resize(item.w,item.h);f.fills=[];f.strokes=[];f.clipsContent=!!item.clip;f.itemSpacing=item.gap||0;f.itemReverseZIndex=false;
    const p=item.pad||[0,0,0,0];f.paddingTop=p[0];f.paddingRight=p[1];f.paddingBottom=p[2];f.paddingLeft=p[3];f.primaryAxisAlignItems='MIN';f.counterAxisAlignItems=item.align||'MIN';f.cornerRadius=Math.min(item.radius||0,item.w/2,item.h/2);
    const fills:Paint[]=[];if(item.gradient)fills.push(gradientPaint(item.gradient));if(item.fill)fills.push(solid(item.fill));f.fills=fills;
    const edges=item.borders||[],uniform=edges.length===4&&edges.every(e=>e.width===item.strokeWidth&&JSON.stringify(e.color)===JSON.stringify(item.stroke));
    if(item.stroke&&item.strokeWidth&&(!edges.length||uniform)){f.strokes=[solid(item.stroke)];f.strokeWeight=item.strokeWidth;f.strokeAlign='INSIDE';}
    // Asymmetric CSS separators are paint layers, not layout groups.
    if(!uniform)for(const e of edges){if(!e.width||!e.color)continue;const l=figma.createRectangle();f.appendChild(l);l.name='Разделитель / '+e.side;l.layoutPositioning='ABSOLUTE';const horizontal=e.side==='top'||e.side==='bottom';l.resize(horizontal?item.w:e.width,horizontal?e.width:item.h);l.x=e.side==='right'?item.w-e.width:0;l.y=e.side==='bottom'?item.h-e.width:0;l.fills=[solid(e.color)];l.strokes=[];}
    if(item.wrap){f.layoutWrap='WRAP';f.counterAxisSpacing=item.rowGap||0;f.counterAxisAlignContent='AUTO';}
    node=f;
    // Set dimensions before children; otherwise empty Auto Layout frames collapse text widths.
    if(parent.type!=='PAGE'&&item.abs){f.layoutPositioning='ABSOLUTE';f.x=item.x-origin.x;f.y=item.y-origin.y;}
    for(const c of item.children||[]){
      if(!c.abs&&!item.wrap)gapNode(f,c.before||0,item.mode!=='HORIZONTAL');
      await render(c,f,{x:item.x,y:item.y});
    }
  }else{
    const local={...item,x:item.x-origin.x,y:item.y-origin.y};node=await makeNode(local,parent as FrameNode);
    if(item.type==='TEXT'){
      const t=node as TextNode;t.textAlignHorizontal=item.textAlign==='center'?'CENTER':item.textAlign==='right'?'RIGHT':'LEFT';
      for(const r of item.runs||[]){if(r.end<=r.start)continue;const font=fontCache.get(r.font+':'+r.weight);if(font)t.setRangeFontName(r.start,r.end,font);if(r.color)t.setRangeFills(r.start,r.end,[solid(r.color)]);if(r.fontSize)t.setRangeFontSize(r.start,r.end,r.fontSize);}
    }
  }
  if(parent.type!=='PAGE'){
    node.layoutGrow=0;node.layoutAlign='INHERIT';node.layoutPositioning=item.abs?'ABSOLUTE':'AUTO';
    if(item.abs){
      node.x=item.x-origin.x;node.y=item.y-origin.y;
      if(item.type==='IMAGE'&&item.fit==='FIT'){
        const img=imageCache.get(item.assetId||'')!;const scale=Math.min(item.w/img.width,item.h/img.height),w=img.width*scale,h=img.height*scale;
        const pos=(item.position||'50% 50%').split(' '),px=(parseFloat(pos[0])||0)/100,py=(parseFloat(pos[1])||0)/100;
        (node as RectangleNode).resize(w,h);node.x+=(item.w-w)*px;node.y+=(item.h-h)*py;
      }
    }
  }
  node.name=item.name;node.opacity=Math.max(0,Math.min(1,item.opacity??1));boxMeta(node,item);if(item.href)node.setPluginData('sourceHref',item.href);if(current)current.nodes++;return node;
}
async function importScreen(screen:Screen){
  if(!current)throw Error('Импорт не запущен.');
  let page=current.pages.get(screen.width);
  if(!page){page=figma.createPage();page.name='VALMO STRUCTURE v5 / '+screen.width+' px';current.pages.set(screen.width,page);}
  await figma.setCurrentPageAsync(page);
  const index=current.index.get(screen.width)||0,x=index*(screen.width+160);let y=0;
  for(let i=0;i<screen.blocks.length;i++){
    const block=screen.blocks[i];const frame=await render(block.scene,page,{x:0,y:0},true) as FrameNode;
    frame.name=(screen.route==='/'?'Главная':'Каталог')+' / '+String(i+1).padStart(2,'0')+' '+block.name+' / '+screen.width;frame.x=x;frame.y=y;
    if(Array.isArray(frame.fills)&&!frame.fills.length)frame.fills=[{type:'SOLID',color:{r:.9843,g:.9804,b:.9764705882352941}}];
    frame.setPluginData('sourceRoute',screen.route);frame.setPluginData('viewport',String(screen.width));frame.setPluginData('tildaImport','root-frame');frame.setPluginData('layoutVersion','semantic-v5');
    y+=frame.height+80;current.frames++;post({type:'block-done',name:frame.name});await new Promise<void>(r=>setTimeout(r,0));
  }
  current.index.set(screen.width,index+1);post({type:'screen-done',route:screen.route,variant:screen.variant,width:screen.width,frames:current.frames,nodes:current.nodes});
}
figma.ui.onmessage=async(message:any)=>{
  if(message.type==='converted'){
    const pending=conversion.get(message.id);if(!pending)return;clearTimeout(pending.timer);conversion.delete(message.id);
    if(message.error)pending.reject(Error(message.error));else pending.resolve(new Uint8Array(message.bytes));return;
  }
  if(message.type==='local-assets'){
    try{for(const asset of message.assets){const image=figma.createImage(new Uint8Array(asset.bytes));imageCache.set(asset.id,{hash:image.hash,...await image.getSizeAsync()});}post({type:'local-assets-ready',count:message.assets.length,id:message.id});}catch(e){post({type:'error',message:String(e)});}return;
  }
  if(message.type==='cancel'){cancelled=true;return;}
  try{
    if(message.type==='start'){
      if(run)return;run=true;cancelled=false;
      const failures=await preflight(message.assets,message.fonts);
      if(failures.length||cancelled){run=false;post({type:'preflight-failed',failures,cancelled});return;}
      current={pages:new Map(),index:new Map(),rowY:new Map(),rowH:new Map(),frames:0,nodes:0};post({type:'ready-for-screen'});
    }else if(message.type==='screen'){
      if(cancelled){run=false;post({type:'cancelled',frames:current?.frames});return;}
      await importScreen(message.screen);post({type:'ready-for-screen'});
    }else if(message.type==='finish'){
      run=false;
      const page=current?.pages.get(1200)||current?.pages.get(320);if(page){await figma.setCurrentPageAsync(page);const first=page.children.find(n=>n.type==='FRAME') as FrameNode|undefined;if(first){figma.currentPage.selection=[first];figma.viewport.scrollAndZoomIntoView([first]);}}
      post({type:'finished',frames:current?.frames,nodes:current?.nodes,cancelled});figma.notify(cancelled?'Импорт остановлен.':'Созданы смысловые Auto Layout группы 1200 и 320 px.');
    }
  }catch(e){run=false;post({type:'error',message:String(e)});}
};
