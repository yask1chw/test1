const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname;const data=JSON.parse(fs.readFileSync(root+'/layout.json'));
let nodes=[],messages=[],page,images=new Map(),counter=0,allowNetwork=false;
class Node{
 constructor(type){this.id=String(++counter);this.type=type;this.children=[];this.parent=null;this.width=24;this.height=24;this.x=0;this.y=0;this.fills=[];this.strokes=[];this.meta={};nodes.push(this);}
 appendChild(node){if(node.parent)node.parent.children=node.parent.children.filter(n=>n!==node);this.children.push(node);node.parent=this;}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(n=>n!==this);this.parent=null;this.removed=true;}
 resize(w,h){assert(Number.isFinite(w)&&Number.isFinite(h)&&w>0&&h>0);this.width=w;this.height=h;}
 rescale(scale){this.width*=scale;this.height*=scale;}
 setPluginData(k,v){this.meta[k]=v;}
 findAll(predicate){const all=[];function go(n){for(const child of n.children){if(predicate(child))all.push(child);go(child)}}go(this);return all;}
 setRangeFontName(a,b,v){assert(b<=this.characters.length);this.richFont=true;}
 setRangeFills(a,b,v){assert(b<=this.characters.length);this.richFills=(this.richFills||[]).concat(v);}
 setRangeFontSize(){}
 async exportAsync(){return new Uint8Array([137,80,78,71]);}
}
const initial=new Node('PAGE');page=initial;
function make(type){const n=new Node(type);page.appendChild(n);return n}
function image(){const hash='image-'+images.size;const img={hash,getSizeAsync:async()=>({width:600,height:400}),getBytesAsync:async()=>new Uint8Array([137,80,78,71])};images.set(hash,img);return img}
const fontNames=['Regular','Medium','SemiBold','Bold','ExtraBold'].flatMap(style=>['Manrope','Oswald'].map(family=>({fontName:{family,style}})));
const figma={ui:{onmessage:null,postMessage(m){messages.push(m);if(m.type==='convert-image')setTimeout(()=>figma.ui.onmessage({type:'converted',id:m.id,bytes:[137,80,78,71]}),0);}},showUI(){},listAvailableFontsAsync:async()=>fontNames,loadFontAsync:async()=>{},createImageAsync:async()=>{if(!allowNetwork)throw Error('fixture network denied');return image()},createImage:()=>image(),getImageByHash:hash=>images.get(hash),createNodeFromSvg:()=>make('FRAME'),createText:()=>make('TEXT'),createRectangle:()=>make('RECTANGLE'),createEllipse:()=>make('ELLIPSE'),createFrame:()=>make('FRAME'),createPage:()=>new Node('PAGE'),setCurrentPageAsync:async p=>{page=p;figma.currentPage=p},currentPage:initial,viewport:{scrollAndZoomIntoView(){}},notify(){}};
const context={figma,__html__:'UI fixture',fetch:async()=>{if(!allowNetwork)throw Error('fixture network denied');return {ok:true,text:async()=>'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><path d="M0 0L24 24"/></svg>',arrayBuffer:async()=>new ArrayBuffer(4)}},setTimeout,clearTimeout,console,Uint8Array,Map,Math,Promise};
vm.runInNewContext(fs.readFileSync(root+'/plugin/code.js','utf8'),context);
function arrange(f){
 if(f.type!=='FRAME')return;
 const children=f.children.filter(c=>c.layoutPositioning!=='ABSOLUTE'),v=f.layoutMode==='VERTICAL',pt=f.paddingTop||0,pl=f.paddingLeft||0,pr=f.paddingRight||0,pb=f.paddingBottom||0,g=f.itemSpacing||0;
 const avail=v?f.width-pl-pr:f.height-pt-pb,factor=f.counterAxisAlignItems==='CENTER'?.5:f.counterAxisAlignItems==='MAX'?1:0;
 if(f.layoutWrap==='WRAP'){
  let rows=[[]],used=0;
  for(const c of children){if(rows.at(-1).length&&used+g+c.width>f.width-pl-pr+.01){rows.push([]);used=0;}if(rows.at(-1).length)used+=g;rows.at(-1).push(c);used+=c.width;}
  let y=pt;for(const row of rows){let x=pl;for(const c of row){c.x=x;c.y=y;x+=c.width+g;}y+=Math.max(...row.map(c=>c.height))+(f.counterAxisSpacing||0);}
 }else{
  let p=v?pt:pl;for(const c of children){const cross=(avail-(v?c.width:c.height))*factor;if(v){c.y=p;c.x=pl+cross;p+=c.height+g;}else{c.x=p;c.y=pt+cross;p+=c.width+g;}}
 }
 for(const c of f.children)arrange(c);
}
(async()=>{
 const requests=new Map();for(const s of data.screens)for(const b of s.blocks)for(const n of b.nodes)if(n.type==='TEXT')for(const t of [n,...n.runs||[]])requests.set(t.font+':'+t.weight,{family:t.font,weight:t.weight});const fonts=[...requests.values()];
 await figma.ui.onmessage({type:'start',assets:[data.assets[0]],fonts});assert(messages.some(m=>m.type==='preflight-failed'));assert(!nodes.some(n=>n.meta.tildaImport),'frames created without photos');
 allowNetwork=true;messages=[];await figma.ui.onmessage({type:'start',assets:data.assets,fonts});assert(messages.some(m=>m.type==='ready-for-screen'));
 for(const screen of data.screens){await figma.ui.onmessage({type:'screen',screen});assert(!messages.some(m=>m.type==='error'),JSON.stringify(messages.find(m=>m.type==='error')));}
 await figma.ui.onmessage({type:'finish'});assert(messages.some(m=>m.type==='finished'));
 const frames=nodes.filter(n=>!n.removed&&n.meta.tildaImport);assert.equal(frames.length,data.screens.reduce((a,s)=>a+s.blocks.length,0));
 const errors=[];let maxGroupDepth=0,checked=0,groupCount=0,imageCount=0,buttonCount=0,absoluteCount=0,spacerCount=0;
 function walk(n,depth,x,y){
  if(n.type==='FRAME'){maxGroupDepth=Math.max(maxGroupDepth,depth);groupCount++;assert(['HORIZONTAL','VERTICAL'].includes(n.layoutMode));assert(!/^(layer \/|position$|content$)/.test(n.name),'position wrapper reintroduced');}
  if(n.meta.layoutSpacer)spacerCount++;
  if(n.name==='button')buttonCount++;
  if(n.layoutPositioning==='ABSOLUTE')absoluteCount++;
  if(n.fills.some(p=>p.type==='IMAGE'))imageCount++;
  if(n.meta.sourceBox){const s=JSON.parse(n.meta.sourceBox);let error=Math.max(Math.abs(x-s.x),Math.abs(y-s.y),Math.abs(n.width-s.w),Math.abs(n.height-s.h));
   const absoluteFit=n.layoutPositioning==='ABSOLUTE'&&n.fills.some(p=>p.type==='IMAGE')&&n.width<=s.w&&n.height<=s.h;
   if(absoluteFit){assert(x>=s.x-.01&&y>=s.y-.01&&x+n.width<=s.x+s.w+.01&&y+n.height<=s.y+s.h+.01);}else if(error>2.1)errors.push({name:n.name,error,source:s,actual:{x,y,w:n.width,h:n.height}});checked++;}
  for(const c of n.children)walk(c,depth+(c.type==='FRAME'?1:0),x+c.x,y+c.y);
 }
 for(const f of frames){arrange(f);walk(f,1,0,0);}
 assert(maxGroupDepth<=6,'group nesting exceeds 6');assert.equal(errors.length,0,JSON.stringify(errors.slice(0,8)));assert(buttonCount>60);assert(groupCount<1000);assert(imageCount>100);const separators=nodes.filter(n=>!n.removed&&n.name?.startsWith('Разделитель /')).length;let sourceAbsolute=0;function abs(n){if(n.abs)sourceAbsolute++;for(const c of n.children||[])abs(c);}for(const s of data.screens)for(const b of s.blocks)for(const c of b.scene.children||[])abs(c);assert.equal(absoluteCount,sourceAbsolute+separators,'non-decorative layers made absolute');
 const headings=nodes.filter(n=>!n.removed&&n.type==='TEXT'&&n.characters?.includes('ТЕХНИКА, КОТОРАЯ'));assert(headings.length===2);assert(headings.every(n=>n.richFills?.some(p=>p.color.r>.6&&p.color.g<.2)),'heading red run lost');
 assert(data.screens.every(s=>s.route==='/'||s.route==='/catalog'));assert(data.screens.every(s=>s.width===1200||s.width===320));
 const report={frames:frames.length,groups:groupCount,checkedSourceBoxes:checked,maxGroupDepth,buttonGroups:buttonCount,imageLayers:imageCount,absoluteDecorativeLayers:absoluteCount,transparentSpacingShapes:spacerCount,geometryErrorsOver2px:errors.length,missingPhotoPreflight:true,richHeadingsPreserved:true,perElementPositionWrappers:0,liveFigmaTested:false,liveTildaTested:false,photoNetwork:'fixture only; actual URLs checked during user import',method:'TypeScript with Figma API types + API mock; CSS Flex geometry checked separately'};
 fs.writeFileSync(root+'/validation-plugin.json',JSON.stringify(report,null,2));console.log(report);
})().catch(e=>{console.error(e);process.exitCode=1});
