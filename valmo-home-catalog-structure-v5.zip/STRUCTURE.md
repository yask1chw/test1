# Фактические группы v5

Список ниже взят из layout.json. Отступы показывают вложенность. Текстовые и графические листья не создают групп.


## / / 1200 px / Техника, которая работает на ваш бизнес

```text
Техника, которая работает на ваш бизнес [VERTICAL]
  IMAGE / новые самосвалы Shacman X5000
  RECT / Фон / div
  RECT / Фон / div
  IMAGE / новые самосвалы Shacman X5000
  Группа / Техника, которая работает на ваш бизнес [VERTICAL]
    Ряд / VALMO RUS / СПЕЦТЕХНИКА [HORIZONTAL]
      RECT / Фон / span
      TEXT / VALMO RUS / СПЕЦТЕХНИКА
    TEXT / ТЕХНИКА, КОТОРАЯ РАБОТАЕТ НА ВАШ БИЗНЕС
    TEXT / Самосвалы, тягачи и спецтехника в наличии по России. Подберём мод
    Ряд / Выбрать техникуПолучить предложение [HORIZONTAL]
      button [HORIZONTAL]
        TEXT / ВЫБРАТЬ ТЕХНИКУ
        SVG / ri-arrow-right-line
      button [HORIZONTAL]
        TEXT / ПОЛУЧИТЬ ПРЕДЛОЖЕНИЕ
    TEXT / Ответим по цене, наличию и срокам поставки.
  Группа / 300+машин в наличиис 2010года на рынкеот [HORIZONTAL]
    Группа / 300+машин в наличии [VERTICAL]
      TEXT / 300+
      TEXT / МАШИН В НАЛИЧИИ
    Группа / с 2010года на рынке [VERTICAL]
      TEXT / с 2010
      TEXT / ГОДА НА РЫНКЕ
    Группа / от 1%аванс по лизингу [VERTICAL]
      TEXT / от 1%
      TEXT / АВАНС ПО ЛИЗИНГУ
    Группа / 10+городов России [VERTICAL]
      TEXT / 10+
      TEXT / ГОРОДОВ РОССИИ
  Ряд / 01 / 07 [HORIZONTAL / поверх фона]
    TEXT / 01 / 07
    button [HORIZONTAL]
      SVG / ri-arrow-left-s-line
    button [HORIZONTAL]
      SVG / ri-arrow-right-s-line
  Шапка / навигация [HORIZONTAL / поверх фона]
    IMAGE / Valmo Rus — спецтехника и коммерческий транспорт
    Навигация [HORIZONTAL]
      Группа / Каталог [HORIZONTAL]
        TEXT / Каталог
        SVG / ri-arrow-down-s-line
      TEXT / В наличии
      TEXT / Лизинг
      TEXT / Сервис
      TEXT / Компания
      TEXT / Контакты
    Ряд / 8 800 777 54 29Получить КП [HORIZONTAL]
      button [HORIZONTAL]
        SVG / ri-search-line
      TEXT / 8 800 777 54 29
      button [HORIZONTAL]
        TEXT / ПОЛУЧИТЬ КП
```

## / / 1200 px / LiuGong 835H

```text
LiuGong 835H [HORIZONTAL]
  Группа / LiuGong 835H [VERTICAL]
    Ряд / VALMO / В НАЛИЧИЕ ПРЯМО СЕЙЧАС [HORIZONTAL]
      RECT / Фон / span
      TEXT / VALMO / В НАЛИЧИЕ ПРЯМО СЕЙЧАС
    TEXT / LIUGONG 835H
    TEXT / Фронтальный погрузчик · LiuGong
    Сетка [HORIZONTAL]
      Группа / 1,8 м³Объём ковша [VERTICAL]
        TEXT / 1,8 м³
        TEXT / ОБЪЁМ КОВША
      Группа / 10 075 кгЭксплуатационная масса [VERTICAL]
        TEXT / 10 075 кг
        TEXT / ЭКСПЛУАТАЦИОННАЯ МАССА
      Группа / 85 / 116 кВт / л.с.Мощность [VERTICAL]
        TEXT / 85 / 116 кВт / л.с.
        TEXT / МОЩНОСТЬ
    Ряд / В наличииГарантия 1 год [HORIZONTAL]
      Ряд / В наличии [HORIZONTAL]
        SVG / ri-checkbox-circle-fill
        TEXT / В НАЛИЧИИ
      TEXT / Гарантия 1 год
    Ряд / Получить предложениеПодробнее [HORIZONTAL]
      button [HORIZONTAL]
        TEXT / ПОЛУЧИТЬ ПРЕДЛОЖЕНИЕ
      Ряд / Подробнее [HORIZONTAL]
        TEXT / ПОДРОБНЕЕ
        SVG / ri-arrow-right-line
  IMAGE / LiuGong 835H — Фронтальный погрузчик
```

## /catalog / 1200 px / Каталог / фильтры и модели / 1

```text
Каталог / фильтры и модели [HORIZONTAL]
  Группа / Фильтр [VERTICAL]
    TEXT / Фильтр
    Группа / Поиск по моделиБрендВсеLiuGongSHACMANНал [VERTICAL]
      Группа / Поиск по модели [VERTICAL]
        TEXT / ПОИСК ПО МОДЕЛИ
        Группа /  [VERTICAL]
          SVG / ri-search-line
          Поле / Модель, бренд или тип [HORIZONTAL]
            TEXT / Модель, бренд или тип
      Группа / БрендВсеLiuGongSHACMAN [VERTICAL]
        TEXT / БРЕНД
        Ряд / ВсеLiuGongSHACMAN [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Все
          button [HORIZONTAL]
            TEXT / LiuGong
          button [HORIZONTAL]
            TEXT / SHACMAN
      Группа / НаличиеЛюбоеВ наличииПод заказ [VERTICAL]
        TEXT / НАЛИЧИЕ
        Ряд / ЛюбоеВ наличииПод заказ [HORIZONTAL WRAP]
          button [HORIZONTAL]
            TEXT / Любое
          button [HORIZONTAL]
            TEXT / В наличии
          button [HORIZONTAL]
            TEXT / Под заказ
      Группа / Тип техникиВсе типыФронтальный погрузчик [VERTICAL]
        TEXT / ТИП ТЕХНИКИ
        Поле / Все типы [HORIZONTAL]
          TEXT / Все типы
      button [HORIZONTAL]
        SVG / ri-refresh-line
        TEXT / Сбросить фильтры
  Группа / LiuGong 835H [VERTICAL]
    TEXT / Найдено: 88
    Сетка / LiuGong 835H [HORIZONTAL WRAP]
      Карточка / LiuGong 835H [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong 835H — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong 835H
        Характеристики [HORIZONTAL WRAP]
          Группа / Объём ковша1,8 м³ [VERTICAL]
            TEXT / Объём ковша
            TEXT / 1,8 м³
          Группа / Эксплуатационная масса10 075 кг [VERTICAL]
            TEXT / Эксплуатационная масса
            TEXT / 10 075 кг
          Группа / Мощность85 / 116 кВт / л.с. [VERTICAL]
            TEXT / Мощность
            TEXT / 85 / 116 кВт / л.с.
          Группа / Высота выгрузки2 930 мм [VERTICAL]
            TEXT / Высота выгрузки
            TEXT / 2 930 мм
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong ZL30 [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong ZL30 — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong ZL30
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong 836 [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong 836 — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong 836
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong CLG835H [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong CLG835H — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong CLG835H
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong 856H [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong 856H — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong 856H
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong CLG856 [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong CLG856 — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong CLG856
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong CLG870H [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong CLG870H — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong CLG870H
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong CLG836 [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong CLG836 — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong CLG836
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong 816С [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong 816С — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong 816С
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
      Карточка / LiuGong CLG820C [VERTICAL]
        Группа / В наличии [VERTICAL]
          IMAGE / LiuGong CLG820C — Фронтальный погрузчик
          Группа / В наличии [HORIZONTAL / поверх фона]
            TEXT / В наличии
        TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
        TEXT / LiuGong CLG820C
        Ряд / ПодробнееУзнать цену [HORIZONTAL]
          button [HORIZONTAL]
            TEXT / Подробнее
          button [HORIZONTAL]
            TEXT / Узнать цену
```

## /catalog / 320 px / Каталог / фильтры и модели / 1

```text
Каталог / фильтры и модели [VERTICAL]
  Группа / Фильтр [HORIZONTAL]
    TEXT / Найдено: 88
    button [HORIZONTAL]
      SVG / ri-equalizer-line
      TEXT / Фильтры
  Группа / LiuGong 835H [VERTICAL]
    Карточка / LiuGong 835H [VERTICAL]
      Группа / В наличии [VERTICAL]
        IMAGE / LiuGong 835H — Фронтальный погрузчик
        Группа / В наличии [HORIZONTAL / поверх фона]
          TEXT / В наличии
      TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
      TEXT / LiuGong 835H
      Характеристики [HORIZONTAL WRAP]
        Группа / Объём ковша1,8 м³ [VERTICAL]
          TEXT / Объём ковша
          TEXT / 1,8 м³
        Группа / Эксплуатационная масса10 075 кг [VERTICAL]
          TEXT / Эксплуатационная масса
          TEXT / 10 075 кг
        Группа / Мощность85 / 116 кВт / л.с. [VERTICAL]
          TEXT / Мощность
          TEXT / 85 / 116 кВт / л.с.
        Группа / Высота выгрузки2 930 мм [VERTICAL]
          TEXT / Высота выгрузки
          TEXT / 2 930 мм
      Ряд / ПодробнееУзнать цену [HORIZONTAL]
        button [HORIZONTAL]
          TEXT / Подробнее
        button [HORIZONTAL]
          TEXT / Узнать цену
    Карточка / LiuGong ZL30 [VERTICAL]
      Группа / В наличии [VERTICAL]
        IMAGE / LiuGong ZL30 — Фронтальный погрузчик
        Группа / В наличии [HORIZONTAL / поверх фона]
          TEXT / В наличии
      TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
      TEXT / LiuGong ZL30
      Ряд / ПодробнееУзнать цену [HORIZONTAL]
        button [HORIZONTAL]
          TEXT / Подробнее
        button [HORIZONTAL]
          TEXT / Узнать цену
    Карточка / LiuGong 836 [VERTICAL]
      Группа / В наличии [VERTICAL]
        IMAGE / LiuGong 836 — Фронтальный погрузчик
        Группа / В наличии [HORIZONTAL / поверх фона]
          TEXT / В наличии
      TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
      TEXT / LiuGong 836
      Ряд / ПодробнееУзнать цену [HORIZONTAL]
        button [HORIZONTAL]
          TEXT / Подробнее
        button [HORIZONTAL]
          TEXT / Узнать цену
    Карточка / LiuGong CLG835H [VERTICAL]
      Группа / В наличии [VERTICAL]
        IMAGE / LiuGong CLG835H — Фронтальный погрузчик
        Группа / В наличии [HORIZONTAL / поверх фона]
          TEXT / В наличии
      TEXT / LIUGONG · ФРОНТАЛЬНЫЙ ПОГРУЗЧИК
      TEXT / LiuGong CLG835H
      Ряд / ПодробнееУзнать цену [HORIZONTAL]
        button [HORIZONTAL]
          TEXT / Подробнее
        button [HORIZONTAL]
          TEXT / Узнать цену
```
